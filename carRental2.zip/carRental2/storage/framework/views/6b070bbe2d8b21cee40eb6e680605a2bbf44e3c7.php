<?php /* E:\laravel\carRental2\resources\views/carowner/status.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>RentZentric</title>

  <!-- Favicons -->
 <link href="employee/img/favicon.png" rel="icon">
  <link href="employee/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="employee/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="employee/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="employee/css/style.css" rel="stylesheet">
  <link href="employee/css/style-responsive.css" rel="stylesheet"> 
 <link href="employee/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="employee/css/galleryeffect.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="employee/css/jquery.flipster.css">
		<link rel='stylesheet' href='employee/css/dscountdown.css' type='text/css' media='all' />
<link href="employee/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="employee/css/font-awesome.css" rel="stylesheet"> 
<link href="//fonts.googleapis.com/css?family=Press+Start+2P" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Faster+One" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
 
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="employee/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" type="text/css" href="employee/css/zoomslider.css" />
<link rel="stylesheet" type="text/css" href="employee/css/style.css" />
<link rel="stylesheet" type="text/css" href="employee/css/component.css" />
<link rel="stylesheet" type="text/css" href="employee/css/jquery-ui1.css">
			<link href="employee/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />

<script type="text/javascript" src="employee/js/modernizr-2.6.2.min.js"></script>
<!--/web-fonts-->
	<link href='//fonts.googleapis.com/css?family=Open+Sans:400,600,600italic,300,300italic,700,400italic' rel='stylesheet' type='text/css'>
	<link href='//fonts.googleapis.com/css?family=Wallpoet' rel='stylesheet' type='text/css'>
	<link href='//fonts.googleapis.com/css?family=Ubuntu:400,500,700,300' rel='stylesheet' type='text/css'> 
  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
  <style>
table, td, th {
    border: 1px solid #990099;
	
	padding: 15px;
    text-align: left;
}

table {
    border-collapse: collapse;
    width: 100%;
}

th {
    height: 50px;
}
h4
{
color:#0000FF;
}
</style>
<script type="text/javascript">
    $('#image1Large').hide().click(function() {
        $(this).hide();
    });

    $('#image1').click(function() {
        $('#image1Large').attr('src', this.src)
            .show()
            .offset({ top: 0, left: 0 });
    });
	protected void LoadImage1()
{
    SqlCommand cmd = new SqlCommand("sps_getimage", con);
    cmd.CommandType = CommandType.StoredProcedure;
    cmd.Parameters.AddWithValue("@flag", 1);
    cmd.Parameters.AddWithValue("@ad_id", ad_id);
    con.Open();
    SqlDataReader reader = cmd.ExecuteReader(System.Data.CommandBehavior.SequentialAccess);
    if (reader.HasRows)
    {
        reader.Read();
        MemoryStream memory = new MemoryStream();
        long startIndex = 0;
        const int ChunkSize = 256;
        while (true)
        {
            byte[] buffer = new byte[ChunkSize];
            long retrievedBytes = reader.GetBytes(0, startIndex, buffer, 0, ChunkSize);
            memory.Write(buffer, 0, (int)retrievedBytes);
            startIndex += retrievedBytes;
            if (retrievedBytes != ChunkSize)
                break;
        }
</script>
</head>

<body>
  <section id="container">
     
       
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>Rent<span>Zentric</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
          <!-- settings start -->
          <li class="dropdown">
            <!--a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-tasks"></i>
              <span class="badge bg-theme">4</span>
              </a>
            <ul class="dropdown-menu extended tasks-bar">
              <div class="notify-arrow notify-arrow-green"></div>
              <li>
                <p class="green">You have 4 pending tasks</p>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Dashio Admin Panel</div>
                    <div class="percent">40%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                      <span class="sr-only">40% Complete (success)</span>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Database Update</div>
                    <div class="percent">60%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
                      <span class="sr-only">60% Complete (warning)</span>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Product Development</div>
                    <div class="percent">80%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                      <span class="sr-only">80% Complete</span>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Payments Sent</div>
                    <div class="percent">70%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%">
                      <span class="sr-only">70% Complete (Important)</span>
                    </div>
                  </div>
                </a>
              </li>
              <li class="external">
                <a href="#">See All Tasks</a>
              </li>
            </ul>
          </li>
          <!-- settings end -->
          <!-- inbox dropdown start-->
          <!--li id="header_inbox_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-envelope-o"></i>
              <span class="badge bg-theme">5</span>
              </a>
            <ul class="dropdown-menu extended inbox">
              <div class="notify-arrow notify-arrow-green"></div>
              <li>
                <p class="green">You have 5 new messages</p>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-zac.jpg"></span>
                  <span class="subject">
                  <span class="from">Zac Snider</span>
                  <span class="time">Just now</span>
                  </span>
                  <span class="message">
                  Hi mate, how is everything?
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-divya.jpg"></span>
                  <span class="subject">
                  <span class="from">Divya Manian</span>
                  <span class="time">40 mins.</span>
                  </span>
                  <span class="message">
                  Hi, I need your help with this.
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-danro.jpg"></span>
                  <span class="subject">
                  <span class="from">Dan Rogers</span>
                  <span class="time">2 hrs.</span>
                  </span>
                  <span class="message">
                  Love your new Dashboard.
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-sherman.jpg"></span>
                  <span class="subject">
                  <span class="from">Dj Sherman</span>
                  <span class="time">4 hrs.</span>
                  </span>
                  <span class="message">
                  Please, answer asap.
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">See all messages</a>
              </li>
            </ul>
          </li>
          <!-- inbox dropdown end -->
          <!-- notification dropdown start-->
          <!--li id="header_notification_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-bell-o"></i>
              <span class="badge bg-warning">7</span>
              </a>
            <ul class="dropdown-menu extended notification">
              <div class="notify-arrow notify-arrow-yellow"></div>
              <li>
                <p class="yellow">You have 7 new notifications</p>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-danger"><i class="fa fa-bolt"></i></span>
                  Server Overloaded.
                  <span class="small italic">4 mins.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-warning"><i class="fa fa-bell"></i></span>
                  Memory #2 Not Responding.
                  <span class="small italic">30 mins.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-danger"><i class="fa fa-bolt"></i></span>
                  Disk Space Reached 85%.
                  <span class="small italic">2 hrs.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-success"><i class="fa fa-plus"></i></span>
                  New User Registered.
                  <span class="small italic">3 hrs.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">See all notifications</a>
              </li>
            </ul>
          </li>
          <!-- notification dropdown end -->
        </ul-->
        <!--  notification end -->
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
        <!--li><a href="employee.profile"><img src="employee/img/user1.png" width="60" height="60"/></a></li-->
          <li><a class="logout" href="/index">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
           <p class="centered"><a href="profile.html"><img src="carowner/img/h.png"  class="img-circle" width="80"></a></p>
          <h5 class="centered"><font color="#0033FF">
                            <?php if(session()->has('email')): ?>
<h4><?php echo e(session()->get('email')); ?></h4>
<?php endif; ?></h5></font>
</center></h5>
          <li class="mt">
            <a href="carowner.index" class="active">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
          </li>
          
         <li class="sub-menu">
            <a href="carowner.profile">
              <i class="fa fa-user-circle"></i>
              <span>Profile</span>
              </a>
          </li>
          <li class="sub-menu">
            <a href="carowner.carlist">
              <i class="fa fa-car"></i>
              <span>Car List</span>
              </a>
           
          </li>
          <li class="sub-menu">
            <a href="carowner.adcar">
              <i class="fa fa-taxi"></i>
              <span>Add Car</span>
              </a>
           
          </li>
           <li class="sub-menu">
            <a href="carowner.status">
              <i class="fa fa-eye"></i>
              <span>View Status</span>
              </a>
           
          </li>
         
          <!--li class="sub-menu">
            <a href="carowner.car">
              <i class="fa fa-tasks"></i>
              <span>Car</span>
              </a>
            <ul class="sub">
              <li><a href="carowner.adcar">Add Car</a></li>
              <li><a href="carowner.status"> Status</a></li>
              
            </ul>
          </li-->

          <li class="sub-menu">
            <a href="carowner.bookingh">
              <i class="fa fa-list"></i>
              <span>Booking History</span>
              </a>
           
          </li>
         
         
         
         
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
        
    <!--main content start-->
    <section id="main-content">
   
     <div class="bus-btm">
	<div class="container">
			<div class="col-md-9 search-car-right-text w3">
            <br>
            <br>
            <br>
            <br>
							<div class="well well-sm">
								<strong>Display</strong>
								<div class="btn-group">
									<a href="#" id="list" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-th-list">
									</span>List</a> <a href="#" id="grid" class="btn btn-default btn-sm two"><span
										class="glyphicon glyphicon-th"></span>Grid</a>
								</div>
							</div>
                              <?php $__currentLoopData = $car; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div id="products" class="row list-group">
								<div class="item  col-xs-4 col-lg-4">
									<div class="thumbnail">
										<img class="group list-group-image" src="storage/upload/<?php echo e($data->car_image); ?>" alt="Catchy Carz">  <?php if($data->status == '1'): ?>        
                    
										<td><font color="#0000FF">APPROVED</font></td>         
									 <?php elseif($data->status=='0'): ?>
                                     <td><font color="#0000FF">APPROVED</font></td> 
                                     <?php else: ?>
										 <td><font color="#0000FF">APPROVAL PENDING</font></td>
									 <?php endif; ?>
                </a>
                                         <!--span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span-->
		                                       <div class="table-text">
                                                                <h4 ><span class="spancarname"><font color="#FF0000"><?php echo e($data->car_brand); ?> <?php echo e($data->car_model); ?></font></span></h4>
                                                                <br><br>
                                                                <h2 ><span class="spancarname"><font size="2px">CAR REGISTER NUMBER: <?php echo e($data->car_regno); ?></font></span></h4>
                                                                
                                                                <p class="gridViewPrice hide">
                                                                   
                                                                        <span class="rupee-lac">$<?php echo e($data->car_rent); ?></span> 
                                                                  
                                                                </p>
                                                                <div class="other-details">
                                                                    
                                                                      <span class="rupee-lac slprice"> $ <?php echo e($data->car_rent); ?></span> 
                                                                    
																<div class="clearfix"></div>																	
                                                                    
                                                                        <p class="listing-item-kms"><span class="slkms"><?php echo e($data->car_actype); ?></span><span class="margin-left5 margin-right5">|</span><span class="fuel"><?php echo e($data->car_ftype); ?></span><span class="margin-left5 margin-right5">|<br></span><span><div class="bus-ic3">
					<!--img src="employee/img/seat.png"  class="img-responsive" alt=""-->
				</div>
				<div class="bus-txt3">
					<h4>Seats:<?php echo e($data->car_nofs); ?></h4>
					
				</div></span></p>
                                                                        <!--p class="listing-item-area"><span class="cityname">
                                                                        G.O.P London</span></p-->
                                                                 
				
				
			</li>
                                                                        <p class="text-light-grey deliverytext"></p>
                                                                  
                                                                </div>
        
         
                                                               <!--div class="clearfix"></div>
                                                                <div class="list-form">
                                                                    <div class="phone-info">
																	   <form action="used_cars.html" method="post">
																	     <input type="text" class="phone" placeholder="Phone" required="">
																	   </form>
																	</div-->
																	
                                                                   
                                                                    <div class="clearfix"></div>
                                                                </div>
                                                               
                                                            </div>
										
									</div>
								</div>
                                  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</li>
          
				<div class="clearfix"></div>
                 
       
       
		</ul>
		<!--- /ul-first  ---->
		<!--- ul-first-1 ---->
       
	</div>
</div>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="employee/lib/jquery/jquery.min.js"></script>
  <script src="employee/lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="employee/lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="employee/lib/jquery.ui.touch-punch.min.js"></script>
  <script class="include" type="text/javascript" src="employee/lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="employee/lib/jquery.scrollTo.min.js"></script>
  <script src="employee/lib/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="employee/lib/common-scripts.js"></script>
  <script type="text/javascript" src="employee/js/bootstrap.js"></script>
<script src="employee/js/jquery-1.11.1.min.js"></script>
<script src="employee/js/bootstrap.js"></script>
					<!---->
							<script type="text/javascript" src="employee/js/jquery-ui.js"></script>
							<script type='text/javascript'>//<![CDATA[ 
							$(window).load(function(){
							 $( "#slider-range" ).slider({
										range: true,
										min: 0,
										max: 200000,
										values: [ 5000, 100000 ],
										slide: function( event, ui ) {  $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
										}
							 });
							$( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) + " - $" + $( "#slider-range" ).slider( "values", 1 ) );

							});//]]>  

							</script>
<script>
  $(document).ready(function() {
    $('#list').click(function(event){event.preventDefault();$('#products .item').addClass('list-group-item');});
    $('#grid').click(function(event){event.preventDefault();$('#products .item').removeClass('list-group-item');$('#products .item').addClass('grid-group-item');});
});
</script>
</script>
<!--style>
.checked {
  color: orange;
}
</style-->
</body>

</html>
 