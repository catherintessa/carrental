<?php /* E:\laravel\carRental\resources\views/logins.blade.php */ ?>
echo "login successufully";