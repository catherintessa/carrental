<?php /* E:\laravel\carRental\resources\views/index.blade.php */ ?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>
<html lang="zxx">


<head>
    <title>RentZentric</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8" />
    <meta name="keywords" content="Trips Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- Custom Theme files -->
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
    <!-- color switch -->
    <link href="css/blast.min.css" rel="stylesheet" />
    <!-- portfolio -->
    <link href="css/portfolio.css" type="text/css" rel="stylesheet" media="all">
    <link href="css/style.css" type="text/css" rel="stylesheet" media="all">
    <!-- font-awesome icons -->
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <!-- //Custom Theme files -->
    <!-- online-fonts -->
    <link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <!-- //online-fonts -->
    <script>
	function isNumberKey(evt)
	{
		var charCode=(evt.which)?evt.which:event.KeyCode;
		if(charCode!=46 && charCode>31 && (charCode<48||charCode>57))
		{
			alert("Enter Number");
			return false;
			}
			return true;
		  }
		function lettersOnly() 
{
            var charCode = event.keyCode;

            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || charCode == 8)

                return true;
            else
			alert("Enter chararctes only");
                return false;
}
</script>
</head>

<body>
    <!-- blast color scheme -->
    <div class="blast-box">
        <div class="blast-frame">
            <p>color schemes</p>
            <div class="blast-colors d-flex justify-content-center">
                <div class="blast-color">#ff4f81</div>
                <div class="blast-color">#77ba00</div>
                <div class="blast-color">#ffa900</div>
                <div class="blast-color">#2ec4b6</div>
                <div class="blast-color">#42a5f5</div>
                <!-- you can add more colors here -->
            </div>
            <p class="blast-custom-colors">Choose Custom color</p>
            <input type="color" name="blastCustomColor" value="#cf2626">

        </div>
        <div class="blast-icon"><i class="fa fa-cog" aria-hidden="true"></i></div>

    </div>
    <!-- //blast color scheme -->
    <!-- top header -->
    <div class="header-top bg-theme" data-blast="bgColor">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <ul class="d-flex header-w3_pvt">
                        <li>
                            <span class="fa fa-envelope-open"></span>
                            <a href="mailto:example@email.com" class="text-white">rentzentric@gmail.com</a>
                        </li>
                        <li>
                            <span class="fa fa-phone"></span>
                            <p class="d-inline text-white">7559006733</p>
                        </li>
                    </ul>
                </div>
                <div class="col-md-6 hearder-right-w3_pvt">
                    <ul class="d-flex header-w3_pvt justify-content-lg-end">
                        <li><button type="button" class="btn w3ls-btn d-block" data-toggle="modal" aria-pressed="false"
                                data-target="#exampleModal1">
                                <span class="fa fa-sign-in"></span>Register
                            </button>
                        </li>
                        <li>
                            <button type="button" class="btn w3ls-btn btn-2  d-block" data-toggle="modal" aria-pressed="false"
                                data-target="#exampleModal">
                                <span class="fa fa-lock"></span> Sign in
                            </button>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- //top header -->
    <!-- banner -->
    <div id="home">
        <!-- header -->
        <header>
            <nav class="navbar navbar-expand-lg navbar-light">
                <h1>
                    <a class="navbar-brand text-white">
                        RentZentric
                    </a>
                </h1>
                <button class="navbar-toggler ml-md-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-lg-auto text-center">
                        <li class="nav-item active  mr-lg-3 mt-lg-0 mt-sm-3">
                            <a class="nav-link" href="index" data-blast="color">Home
                                <span class="sr-only">(current)</span>
                            </a>
                        </li>
                        <li class="nav-item  mr-lg-3 mt-lg-0 mt-3">
                            <a class="nav-link scroll" href="#about">about</a>
                        </li>
                        
                        <li class="nav-item  mt-lg-0 mt-3">
                            <a class="nav-link scroll" href="#contact">Contact</a>
                        </li>
                    </ul>
                </div>

            </nav>
        </header>
        <!-- //header -->
        <div class="callbacks_container">
            <ul class="rslides" id="slider3">
                <li class="banner banner1">
                    <div class="container">
                        <div class="banner-text">
                            <div class="slider-info">
                                <span class="line">Find and Bok</span>
                                <h3>a <span data-blast="bgColor">Great</span>Deal Today</h3>
                                <p class="text-white">We Give Best Service</p>
                                <a class="btn bg-theme mt-4 w3_pvt-link-bnr scroll text-white" data-blast="bgColor"
                                    href="#about" role="button">View
                                    More</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="banner banner2">
                    <div class="container">
                        <div class="banner-text">
                            <div class="slider-info">
                                <span class="line">Find and Book</span>
                                <h3>a <span data-blast="bgColor">Great</span>Deal Today!</h3>
                                <p class="text-white">We Give Best Service </p>
                                <a class="btn bg-theme mt-4 w3_pvt-link-bnr scroll text-white" href="#about" role="button"
                                    data-blast="bgColor">View
                                    More</a>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <!-- //banner -->
    <!-- about -->
    <div class="about-wthree" id="about">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-5 about-right-bg"></div>
                <div class="col-lg-7 about-left-wthree bg-theme" data-blast="bgColor">
                    <div class="title-desc text-right pb-sm-3">
                        <h3 class="main-title-w3pvt text-white text-capitalize">about us</h3>
                        <p class="text-white">Explore it all. The sky is the limit!</p>
                    </div>
                    <p class="my-3 text-right text-white child_second"><font align="center"> Our fleet is composed of full-featured and technologically advanced car models from different makers which is young and well maintained. We have Economy, Premium & Luxury cars for 
rent based on your needs ranging from wedding to business trip. The quality of services permits you to travel in style making a business
 trip or a vacation to ‘Kerala’ The God’s own country more enjoyable and comfortable. We have got a set of well trained chauffeurs to make
 sure that your special occasion is taken care of. We at Dealz Travels offer self driven car rental service in Cochin ranging from daily, 
 weekly & monthly rental based on your requirements. Rent a car from Dealz and make most of it !</font></p>
                    <!--p class="my-3 text-right text-white child_second">Donec mi nulla, auctor nec sem a, ornare. Sed mi
                        tortorcomm odo a felis
                        in, fringilla tincidunt nulla.</p>-->
      <div class="ml-auto text-right">
                        <a href="#plans" class="text-capitalize text-dark w3_pvt-link-bnr btn bg-light scroll mt-sm-4">view
                            more</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- about -->
    <!-- services -->

    <!-- //team -->
    <!-- contact -->
    <div class="contact-wthree pt-lg-5" id="contact">
        <div class="container py-md-5 py-4">
            <div class="title-desc text-left pb-3">
                <h3 class="main-title-w3pvt  text-capitalize">contact</h3>
                <p>Explore it all. The sky is the limit!</p>
            </div>
            <div class="row py-lg-5 py-sm-4">
                <div class="col-lg-12">
                    <div class="w3_pvt-contact-top">
                        <h2>get in touch </h2>
                        <ul class="d-flex header-wthreelayouts pt-0 flex-column">
                            <li>
                                <span class="fa fa-home" data-blast="color"></span>
                                <p class="d-inline"> GS2 Heavenly Plaza,Suite No. 509, Kakkanad<br>
							Cochin, India - 682 021</p>
                            </li>
                            <li class="my-3">
                                <span class="fa fa-envelope-open" data-blast="color"></span>
                                <a href="mailto:example@email.com" class="text-secondary">rentzentric@gmail.com</a>
                            </li>
                            <li>
                                <span class="fa fa-phone" data-blast="color"></span>
                                <p class="d-inline">7559006733</p>
                            </li>
                        </ul>
                    </div>
                    <hr>
                    <div class="col-lg-12 mt-4">
                        <!-- register form grid -->
                        <div class="register-top1">
                            <form action="/index2" method="post" class="register-wthree" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-3 pl-lg-0">
                                            <label>
                                                Full name
                                            </label>
                                            <input class="form-control" type="text" placeholder="Johnson" name="name"
                                                required="" data-blast="borderColor">
                                        </div>
                                        <div class="col-lg-3 my-lg-0 my-4">
                                            <label>
                                                Email
                                            </label>
                                            <input class="form-control" type="email" placeholder="example@email.com"
                                                name="email" required="" data-blast="borderColor">
                                        </div>
                                        <div class="col-lg-3">
                                            <label>
                                                Mobile
                                            </label>
                                            <input class="form-control" type="text" placeholder="xxxx xxxxx" name="mobile"
                                                required="" data-blast="borderColor">
                                        </div>
                                        <div class="col-lg-3 d-flex align-items-end pr-lg-0 mt-lg-0 mt-4">
                                            <input type="submit" data-blast="bgColor" class="btn btn-w3_pvt btn-block w-100 text-white font-weight-bold text-uppercase bg-theme"
                                                />
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!--  //register form grid ends here -->
                    </div>
                </div>
            </div>
        </div>
        <!-- map -->
        <div class="map p-2">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3023.9503398796587!2d-73.9940307!3d40.719109700000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a27e2f24131%3A0x64ffc98d24069f02!2sCANADA!5e0!3m2!1sen!2sin!4v1441710758555" allowfullscreen  data-blast="borderColor"></iframe>
        </div>
        <!--// map-->
    </div>
    <!-- //contact -->
    <!-- footer -->
    <footer class="cpy-right bg-theme" data-blast="bgColor">
        <div class="container">
            <!--div class="row">
                <div class="col-md-6">
                    <div class="wthree-social">
                        <ul>
                            <li>
                                <a href="#">
                                    <span class="fa fa-facebook-f icon_facebook"></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="fa fa-twitter icon_twitter"></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="fa fa-dribbble icon_dribbble"></span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="fa fa-google-plus icon_g_plus"></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
               
            </div>
        </div>
    </footer>
    < //footer -->
    <!-- login  -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header" data-blast="bgColor">
                    <h5 class="modal-title" id="exampleModalLabel">Signin</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="/index1" method="post" class="p-3">
                    <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Username</label>
                            <input type="text" class="form-control" placeholder="" name="email" id="recipient-name" autocomplete="off"
                                required="">
                        </div>
                        <div class="form-group">
                            <label for="password" class="col-form-label">Password</label>
                            <input type="password" class="form-control" placeholder="" name="password" id="password" autocomplete="off"
                                required="">
                        </div>
                        <div class="right-w3l">
                            <input type="submit" class="form-control" value="Login">
                        </div>
                        <div class="row sub-w3l my-3">
                            <div class="col sub-w3_pvt">
                                <input type="checkbox" id="brand1" value="">
                                <label for="brand1">
                                    <span></span>Remember me?</label>
                            </div>
                            <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                        </div>
                        <p class="text-center dont-do">Don't have an account?
                            <a href="#" data-toggle="modal" data-target="#exampleModal1" class="text-secondary">
                                Register Now</a>

                        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- //login -->
    <!-- register -->
    <!--a onClick=\"$('#ereg').modal('hide);$('#lost').modal('show');\" href="ureg'><Click</a>-->
    <div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel1"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header" data-blast="bgColor">
                    <h5 class="modal-title" id="exampleModalLabel1">Register</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <br>
                  
                <div class="modal-body">
                    <form action="/index" method="post" class="p-3" id="reg" enctype="multipart/form-data"> 
                    <?php echo e(@csrf_field()); ?>

                    <div class="form-group">
                    <label for="recipient-name" class="col-form-label">User Type</label>
                         <br>
                            <select  for="recipient-name" class="col-form-label" name="usertype" style="width: 420px">
                            <option value="customer">Customer</option>
  									<option value="employee">Employee</option>
 									 <option value="carowner">Car Owner</option>
                                      </select>
                                      </div>
  									
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">First Name</label>
                            <input type="text" class="form-control" placeholder="" name="fname" id="fname" autocomplete="off"
                                required="">
                        </div>
                        <div class="form-group">
                         <label for="recipient-name" class="col-form-label">Last Name</label>
                            <input type="text" class="form-control" placeholder="" name="lname" id="lname" autocomplete="off"
                                required="">
                        </div>
                        <div class="form-group">
                         <label for="recipient-name" class="col-form-label">Place</label>
                            <input type="text" class="form-control" placeholder="" name="place" id="place" autocomplete="off"
                              required="">
                        </div>
                         <div class="form-group">
                         <label for="recipient-name" class="col-form-label">District</label>
                         <br>
                            <select  for="recipient-name" class="col-form-label" name="district" style="width: 420px" >
  									<option value="Kasrgode">Kasrgode</option>
  									<option value="Kannur">Kannur</option>
 									 <option value="Kozhikode">Kozhikode</option>
  									<option value="Wayanad">Wayanad</option>
                                    <option value="Malapuram">Malapuram</option>
                                    <option value="Palakad">Palakad</option>
                                    <option value="Ernakulam">Ernakulam</option>
                                    <option value="Idukki">Idukki</option>
                                    <option value="Kottayam">Kottayam</option>
                                    <option value="Alapuzha">Alapuzha</option>
                                    <option value="Pathanamthitta">Pathanamthitta</option>
                                    <option value="Kollam">Kollam</option>
                                    <option value="Thiruvanathapuram">Thiruvanathapuram</option>
                                   
                            </select>
                                                        </div>
                        <div class="form-group">
                         <label for="recipient-name" class="col-form-label">Contact Number</label>
                            <input type="text" class="form-control" placeholder="" name="cno" id="cno"
                                autocomplete="off" required="">
                        </div>
                        <div class="form-group">
                         <label for="recipient-name" class="col-form-label">Pin Code</label>
                            <input type="text" class="form-control" placeholder="" name="pin" id="pin"
                               autocomplete="off" required="">
                        </div>
                         <!--div class="form-group">
                         <label for="recipient-name" class="col-form-label">ID Proof</label>
                            <input type="file" class="form-control" placeholder="" name="idproof" accept="image/jpg, image/jpeg" id="recipient-rname" autocomplete="off"
                                required="">
                        </div-->
                        <div class="form-group">
                         <label for="recipient-name" class="col-form-label">Photo</label>
                            <input type="file" class="form-control" placeholder="" name="photo"  accept="image/jpg, image/jpeg" id="photo" autocomplete="off"
                                required="">
                        </div>
                        <div class="form-group">
                            <label for="recipient-email" class="col-form-label">Email</label>
                            <input type="email" class="form-control" placeholder="" name="email" id="email" autocomplete="off"
                                required="">
                        </div>
                        <div class="form-group">
                            <label for="password1" class="col-form-label">Password</label>
                            <input type="password" class="form-control" placeholder="" name="password" id="password1" autocomplete="off"
                                required="">
                        </div>
                       
                        <div class="form-group">
                            <label for="password2" class="col-form-label">Confirm Password</label>
                            <input type="password" class="form-control" placeholder="" name="cpassword" id="password2" autocomplete="off"
                                required="">
                        </div>
                        <div class="sub-w3l">
                            <div class="sub-w3_pvt">
                                <input type="checkbox" id="brand2" value="">
                                <label for="brand2" class="mb-3">
                                    <span></span>I Accept to the Terms & Conditions</label>
                            </div>
                        </div>
                        <div class="right-w3l">
                            <input type="submit" class="form-control" value="Register">
                        </div>
                    </form>
                    <!--p class="text-center dont-do">if you are a employee?
                            <a href="#" data-toggle="modal" data-target="#exampleModal2" class="text-secondary"><font color="#0000FF">
                                Register Now</font></a>-->
                </div>
            </div>
        </div>
    </div>
     <!--div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel2"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header" data-blast="bgColor">
                    <h5 class="modal-title" id="exampleModalLabel1">Register</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <br>
                  
                <div class="modal-body">
                    <form action="#" method="post" class="p-3">
                    <div class="form-group">
                    <label for="recipient-name" class="col-form-label">User Type</label>
                         <br>
                            <select  for="recipient-name" class="col-form-label" name="usertype" style="width: 400px">
                            <option value="customer">Customer</option>
  									<option value="employee">Employee</option>
 									 <option value="carowner">Car Owner</option>
                                      </select>
                                      </div>
  									
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">First Name</label>
                            <input type="text" class="form-control" placeholder="" name="fname" id="recipient-rname"
                             onKeyPress="return lettersOnly(event)"   required="">
                        </div>
                        <div class="form-group">
                         <label for="recipient-name" class="col-form-label">Last Name</label>
                            <input type="text" class="form-control" placeholder="" name="lname" id="recipient-rname"
                              onKeyPress="return lettersOnly(event)"  required="">
                        </div>
                        <div class="form-group">
                         <label for="recipient-name" class="col-form-label">Place</label>
                            <input type="text" class="form-control" placeholder="" name="place" id="recipient-rname"
                             onKeyPress="return lettersOnly(event)"   required="">
                                 <div class="form-group">
                         <label for="recipient-name" class="col-form-label">District</label>
                         <br>
                            <select  for="recipient-name" class="col-form-label" name="district">
                            <option value="Kasrgode">Kasrgode</option>
  									<option value="Kannur">Kannur</option>
 									 <option value="Kozhikode">Kozhikode</option>
  									<option value="Wayanad">Wayanad</option>
                                    <option value="Malapuram">Malapuram</option>
                                    <option value="Palakad">Palakad</option>
                                    <option value="Ernakulam">Ernakulam</option>
                                    <option value="Idukki">Idukki</option>
                                    <option value="Kottayam">Kottayam</option>
                                    <option value="Alapuzha">Alapuzha</option>
                                    <option value="Pathanamthitta">Pathanamthitta</option>
                                    <option value="Kollam">Kollam</option>
                                    <option value="Thiruvanathapuram">Thiruvanathapuram</option>		
                                   
                            </select>
                                                        </div>
                        </div>
                        <div class="form-group">
                         <label for="recipient-name" class="col-form-label">Contact Number</label>
                            <input type="text" class="form-control" placeholder="" name="cno" id="recipient-rname"
                               pattern="[7-9][0-9]{9}"  required="">
                        </div>
                        <div class="form-group">
                         <label for="recipient-name" class="col-form-label">Pin Code</label>
                            <input type="text" class="form-control" placeholder="" name="pin" id="recipient-rname"
                               pattern="[0-9]{6}"  required="">
                        </div>
                         <div class="form-group">
                         <label for="recipient-name" class="col-form-label">Driving License</label>
                            <input type="file" class="form-control" placeholder="" name="dl" id="recipient-rname"
                                required="">
                        </div>
                        <div class="form-group">
                         <label for="recipient-name" class="col-form-label">Photo</label>
                            <input type="file" class="form-control" placeholder="" name="photo" id="recipient-rname"
                              accept="image/jpg, image/jpeg"  required="">
                        </div>
                        <div class="form-group">
                            <label for="recipient-email" class="col-form-label">Email</label>
                            <input type="email" class="form-control" placeholder="" name="email" id="recipient-email"
                              accept="image/jpg, image/jpeg"  required="">
                        </div>
                        <div class="form-group">
                            <label for="password1" class="col-form-label">Password</label>
                            <input type="password" class="form-control" placeholder="" name="password" id="password1"
                                required="">
                        </div>
                       
                        <div class="form-group">
                            <label for="password2" class="col-form-label">Confirm Password</label>
                            <input type="password" class="form-control" placeholder="" name="cpassword" id="password2"
                                required="">
                        </div>
                        <div class="sub-w3l">
                            <div class="sub-w3_pvt">
                                <input type="checkbox" id="brand2" value="">
                                <label for="brand2" class="mb-3">
                                    <span></span>I Accept to the Terms & Conditions</label>
                            </div>
                        </div>
                        <div class="right-w3l">
                            <input type="submit" class="form-control" value="Register">
                        </div>
                    </form>
                </div>
            </div>
        </div>-->
    <!-- // register -->
    <!-- blog modal1 -->
    
    <!-- //blog modal3-->
    <!-- js -->
    <script src="js/jquery-2.2.3.min.js"></script>
    <!-- //js -->
    <!-- script for password match -->
    <script>
        window.onload = function () {
            document.getElementById("password1").onchange = validatePassword;
            document.getElementById("password2").onchange = validatePassword;
        }

        function validatePassword() {
            var pass2 = document.getElementById("password2").value;
            var pass1 = document.getElementById("password1").value;
            if (pass1 != pass2)
                document.getElementById("password2").setCustomValidity("Passwords Don't Match");
            else
                document.getElementById("password2").setCustomValidity('');
            //empty string means no validation error
        }
    </script>
    <!-- script for password match -->
    <!-- Banner  Responsiveslides -->
    <script src="js/responsiveslides.min.js"></script>
    <script>
        // You can also use"$(window).load(function() {"
        $(function () {
            // Slideshow 4
            $("#slider3").responsiveSlides({
                auto: true,
                pager: true,
                nav: false,
                speed: 500,
                namespace: "callbacks",
                before: function () {
                    $('.events').append("<li>before event fired.</li>");
                },
                after: function () {
                    $('.events').append("<li>after event fired.</li>");
                }
            });

        });
    </script>
    <!-- //Banner  Responsiveslides -->
    <!-- portfolio -->
    <script src="js/jquery.picEyes.js"></script>
    <script>
        $(function () {
            //picturesEyes($('.demo li'));
            $('.demo li').picEyes();
        });
    </script>
    <!-- //portfolio -->
    <!-- start-smooth-scrolling -->
    <script src="js/move-top.js"></script>
    <script src="js/easing.js"></script>
    <script>
        jQuery(document).ready(function ($) {
            $(".scroll").click(function (event) {
                event.preventDefault();

                $('html,body').animate({
                    scrollTop: $(this.hash).offset().top
                }, 1000);
            });
        });
    </script>
    <!-- //end-smooth-scrolling -->
    <!-- smooth-scrolling-of-move-up -->
    <script>
        $(document).ready(function () {
            /*
            var defaults = {
                containerID: 'toTop', // fading element id
                containerHoverID: 'toTopHover', // fading element hover id
                scrollSpeed: 1200,
                easingType: 'linear' 
            };
            */
            $().UItoTop({
                easingType: 'easeOutQuart'
            });

        });
    </script>
    <script src="js/SmoothScroll.min.js"></script>
    <!-- //smooth-scrolling-of-move-up -->
    <!-- color switch -->
    <script src="js/blast.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/jquery.validate.min.js"></script>

    <!-- //color switch -->
    <!-- Bootstrap core JavaScript
================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.js"></script>
</body>



</html>