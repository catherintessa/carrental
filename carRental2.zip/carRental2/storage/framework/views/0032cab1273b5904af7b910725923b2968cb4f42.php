<?php /* E:\laravel\carRental\resources\views/admin/edit.blade.php */ ?>

<style>
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media  screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>

 <h2><center><font color="#990066">Edit Car Details</font></center></h2>   		


<form method="post"  action="<?php echo e(route('admin.edit',$car->id)); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

<div class="row">
      <div class="col-25">
<label for="price">Car Brand</label>
</div>
      <div class="col-75">
<input type="text" name="car_brand" maxlength="9"   required value=<?php echo e($car->car_brand); ?> />
</div>
</div>
<div class="row">
      <div class="col-25">
<label for="price">Car Model</label>
</div>
      <div class="col-75">
<input type="text" name="car_model" required value=<?php echo e($car->car_model); ?>  />
</div>
</div>
<div class="row">
      <div class="col-25">
<label for="price">Fuel Type</label>
</div>
      <div class="col-75">
<input type="text" name="car_ftype"  pattern="[a-zA-Z ]*$" title="Enter valid  Fuel Type" required value=<?php echo e($car->car_ftype); ?>  />
</div> 
</div>      
 <div class="col-25">
<label for="price">Car Image</label>
</div>
      <div class="col-75">
<input type="file" name="car_image"  accept=".jpg,.jpeg,.png,JPG" required value=<?php echo e($car->car_image); ?>  />
</div> 
</div>      


<div class="row-left">
      <input type="submit" value="Update">
   
  
</form>   

<!--market updates updates-->
	
      
<!--main page chit chating end here-->
<!--main page chart start here-->

<!--main page chart layer2-->

	      <!--//Progress bars-->
	      
	