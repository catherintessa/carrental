<?php /* E:\laravel\carRental2\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php */ ?>
<?php echo e($slot); ?>

