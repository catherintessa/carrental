<?php /* E:\laravel\carRental2\resources\views/customer/payment.blade.php */ ?>
<!DOCTYPE HTML>
<html>
<head>
<title>RentZentric</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Green Wheels Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="../customer/applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="../customer/css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="../customer/css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="../customer/css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="../customer/js/jquery-1.12.0.min.js"></script>
<script src="../customer/js/bootstrap.min.js"></script>
<!--animate-->
<link href="../customer/css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="../customer/js/wow.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="../customer/application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="../customer/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="../customer/css/creditly.css" type="text/css" media="all" />
<link rel="stylesheet" href="../customer/css/easy-responsive-tabs.css">
<script src="../customer/js/jquery.min.js"></script>
<link href="//fonts.googleapis.com/css?family=Overpass:100,100i,200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;subset=latin-ext" rel="stylesheet">
	<script>
		 new WOW().init();
	</script>
    <style> 
input[type=button], input[type=submit], input[type=reset] {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 16px 32px;
  text-decoration: none;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
  <script>
	function validate_fileupload(fileName)
{
    var allowed_extensions = new Array("jpg","png");
    var file_extension = fileName.split('.').pop().toLowerCase(); // split function will split the filename by dot(.), and pop function will pop the last element from the array which will give you the extension as well. If there will be no extension then it will return the filename.

    for(var i = 0; i <= allowed_extensions.length; i++)
    {
        if(allowed_extensions[i]==file_extension)
        {
            return true; // valid file extension
        }
    }
		$('#idproof').val(null);
    return false;
}
	function isNumberKey(evt)
	{
		var charCode=(evt.which)?evt.which:event.KeyCode;
		if(charCode!=46 && charCode>31 && (charCode<48||charCode>57))
		{
			// alert("Enter Number");
			return false;
			}
			return true;
		  }
		function lettersOnly() 
{
            var charCode = event.keyCode;

            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || charCode == 8)
                return true;
            else {
							// alert("Enter chararctes only");
                return false;
						}
		
}
function validateForm(){
	return validateemail() && confirmPasword();
}
function confirmPasword() {
	//alert("Password required");  
	var pswd1=document.getElementById("pswd").value;
	var pswd2=document.getElementById("pswdConfirm").value;
	if (pswd1 === "") {
		$('#errMsgPswrd1').html('Password required'); 
		alert("Password required");  
		return false;
	}	else if (pswd1 !== pswd2) {
		$('#errMsgPswrd2').html('Password mismatch'); 
		return false;
	} else {
		return true;
	}
}
function validateemail()  
{  
	var x=document.getElementById("emailId").value;
	console.log('email', x);
	// alert(x);
	if (!validateEmailAddress(x)){ 
		$('#errMsgEmail').html('Invalid Email-id'); 
		//alert("Please enter a valid e-mail address");  
		return false;  

	} else{
		$('#errMsgEmail').html(''); 
		return true;
	}  
}
function validateEmailAddress(address) {
  let isValid = true;
   const emailPattern =  /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
   isValid = emailPattern.test(address);
   return isValid;
}  

</script>
 <script>
	function FSfncCheckCCexpire(FormField) {
	// Check credit expiry date is in valid format
	var CCexpire=FormField.value;
	var FutureDt = new Date();
	var CurrDt = new Date();
	/* alert(CurrDt); */
	if (CCexpire=="") {alert("Please enter your credit card expiry date."); FormField.focus(); return false}
	var ArrayCCexpr=CCexpire.split("/");
	if ((ArrayCCexpr.length!=2) || (ArrayCCexpr[0]=="") || (isNaN(ArrayCCexpr[0])) || (ArrayCCexpr[1]=="") || (isNaN(ArrayCCexpr[1])) || (ArrayCCexpr[0]<1) || (ArrayCCexpr[0]>12)) {alert("Expiry date is not in correct format."); FormField.focus(); return false}
    	FutureDt.setFullYear((ArrayCCexpr[1]*1)+2000,ArrayCCexpr[0],1);
	/* alert(FutureDt); */
    if (FutureDt > CurrDt)
    {
	return true;
    }
    else
	{
		alert("Sorry! Your card is expired!"); return false;
	}
	}
    </script>		
<!--//end-animate-->
</head>
<body>
<!-- top-header -->
<div class="top-header">
	<div class="container">
		<ul class="tp-hd-lft wow fadeInLeft animated" data-wow-delay=".5s">
			<li class="hm"><a href="index.html"><i class="fa fa-home"></i></a></li>
			<!--li class="prnt"><a href="javascript:window.print()">Print/SMS Ticket</a></li-->
            <li>WELCOME:
	 <?php if(session()->has('email')): ?>
<?php echo e(session()->get('email')); ?>

<?php endif; ?></li>
				
		</ul>
		<ul class="tp-hd-rgt wow fadeInRight animated" data-wow-delay=".5s"> 
			<li class="tol">Toll Number :7559006733 </li>				
			<!--li class="sig"><a href="#" data-toggle="modal" data-target="#myModal" >Sign Up</a></li> 
			<li class="sigi"><a href="#" data-toggle="modal" data-target="#myModal4" >/ Sign In</a></li-->
        </ul>
		<div class="clearfix"></div>
	</div>
</div>
<!--- /top-header ---->
<!--- header ---->
<div class="header">
	<div class="container">
		<div class="logo wow fadeInDown animated" data-wow-delay=".5s">
			<a href="index.html">Rent<span>Zentric</span></a>	
		</div>
		<div class="bus wow fadeInUp animated" data-wow-delay=".5s">
            <!--a href="index.html" class="buses active">BUSES</a>
            <a href="hotels.html">HOTELS</a-->
        </div>
		<div class="lock fadeInDown animated" data-wow-delay=".5s"> 
			<li><i class="fa fa-lock"></i></li>
            <li><div class="securetxt">SAFE &amp; SECURE<br> ONLINE PAYMENTS</div></li>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!--- /header ---->
<!--- footer-btm ---->
<div class="footer-btm wow fadeInLeft animated" data-wow-delay=".5s">
	<div class="container">
	<div class="navigation">
			<nav class="navbar navbar-default">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
				  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				  </button>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
					<nav class="cl-effect-1">
						<ul><li><a href="../customer.index">Home</a></li>
								<li><a href="../customer.profile">Profile</a></li>
								<li><a href="../customer.bookingh">Booking History</a></li>
								<li><a href="../customer.search">Search Cars</a></li>
                                  <li><a href="../customer.bookingc">Booking Cancellation</a></li>
								<!--li><a href="travels.html">Travels</a></li>
								<li><a href="privacy.html">Privacy Policy</a></li>
								<li><a href="agent.html">Agent Registration</a></li>
								<li><a href="terms.html">Terms of Use</a></li>
								<li><a href="contact.html">Contact Us</a></li-->
								<!--li>Need Help?<a href="#" data-toggle="modal" data-target="#myModal3"> / Write Us </a>  </li-->
                                <li><a href="/index">Logout</a></li>
								<div class="clearfix"></div>
						</ul>
					</nav>
				</div><!-- /.navbar-collapse -->	
			</nav>
		</div>
		
		<div class="clearfix"></div>
	</div>
</div>
<!--- /footer-btm ---->
<!--- banner-1 ---->
<div class="banner-1">
	<div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;"> Find and Book Great Deal Today</h1>
	</div>
</div>
<!--- /banner-1 ---->
<!--- track ---->
<div class="main">	
		<h1>Fascinating Checkout Form</h1>
		<div class="w3_agile_main_grids">
			<div class="agile_main_top_grid">
				<div class="agileits_w3layouts_main_top_grid_left">
					<a href="#"><img src="../customer/images/1.png" alt=" " /></a>
				</div>
				<div class="w3_agileits_main_top_grid_right">
					<h3>Checkout Form</h3>
				</div>
				<div class="clear"> </div>
				<div class="wthree_total">
					<h2>total amount to pay:<span>1000<i>$</i></span></h2>
				</div>
			</div>
			<div class="agileinfo_main_bottom_grid">
				<div id="horizontalTab">
					<ul class="resp-tabs-list">
						<center><li><img src="../customer/images/1m.jpg" alt=" " /></li></center>
						<!--li><img src="customer/images/2mm.jpg" alt=" " /></li-->
					</ul>
					<div class="resp-tabs-container">
						<div class="agileits_w3layouts_tab1">
							<form action="../customer.payment1" method="post" class="creditly-card-form agileinfo_form">
							<?php echo csrf_field(); ?>
								<section class="creditly-wrapper wthree, w3_agileits_wrapper">
									<div class="credit-card-wrapper">
										<div class="first-row form-group">
											<div class="controls">
                                            <input type="hidden" name="email" value=" <?php if(session()->has('email')): ?><?php echo e(session()->get('email')); ?>

<?php endif; ?>"  />

 <input type="hidden" name="amount" value="1000"/>
 <?php $__currentLoopData = $car; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <input type="hidden" name="b_id" value="<?php echo e($data->b_id); ?>"/>
 <input type="hidden" name="cdate" value="<?php echo e($fd); ?>"/>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<label class="control-label">Name on Card</label>
												<input  type="text" class="billing-address-name form-control" name="name" pattern="[a-zA-Z ]*$" placeholder="John Smith" title="enter character only"   autocomplete="off" required>
											</div>
											<div class="w3_agileits_card_number_grids">
												<div class="w3_agileits_card_number_grid_left">
													<div class="controls">
														<label class="control-label">Card Number</label>
														<input  type="text" class="number credit-card-number form-control" name="cardno"
																	  inputmode="numeric" autocomplete="cc-number" autocompletetype="cc-number" x-autocompletetype="cc-number" placeholder="&#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149; &#149;&#149;&#149;&#149;" pattern="^((?:4\d{3})|(?:5[1-5]\d{2})|(?:6011)|(?:3[68]\d{2})|(?:30[012345]\d))[ -]?(\d{4})[ -]?(\d{4})[ -]?(\d{4}|3[4,7]\d{13})$" minlength="12" maxlength="12" title="enter valid credit card number" required>
													</div>
												</div>
												<div class="w3_agileits_card_number_grid_right">
													<div class="controls">
														<label class="control-label">CVV</label>
														<input type="password" class="security-code form-control"Â·
																	  inputmode="numeric"
																	  name="cvv" minlength="3" maxlength="3"  pattern="[0-9]{3}"
																	  placeholder="&#149;&#149;&#149;" required>
													</div>
												</div>
												<div class="clear"> </div>
											</div>
											<div class="controls">
												<label class="control-label">Expiration Date</label>
												<input  type="text" class="expiration-month-and-year form-control"  name="expdate" placeholder="MM / YY"  minlength="5" maxlength="5" required>
											</div>
										</div>
                                         
										<input type="submit"  value="Make a payment"/>
									</div>
								</section>
							</form>
						</div>
						<!--div class="agileits_w3layouts_tab2">
							<h3>Don't have a paypal Account Please <a href="#">Register</a></h3>
							<form action="#" method="post">
								<label class="agileits_label">Your Email</label>
								<input type="email" name="Email" placeholder="w3layouts@example.com" required="">
								<label class="agileits_label">Your Password</label>
								<input type="password" name="Password" placeholder="Password" required="">
								<input type="submit" value="Login">
							</form-->
						</div>
					</div>
				</div>
			</div>
		</div>

		<!--div class="tracking-top">
			<div class="col-md-6 tracking-left wow fadeInLeft animated" data-wow-delay=".5s">
				<h3>Book your ticket</h3>
				<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
			</div>
			<div class="col-md-6 tracking-right wow fadeInRight animated" data-wow-delay=".5s">
				<img src="images/map1.png" class="img-responsive" alt="">
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="tracking-midle">
			<div class="col-md-6 tracking-right wow fadeInLeft animated" data-wow-delay=".5s">
				<img src="images/map1.png" class="img-responsive" alt="">
			</div>
			<div class="col-md-6 tracking-left wow fadeInRight animated" data-wow-delay=".5s">
				<h3>Boarding</h3>
				<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="tracking-bottom">
			<div class="col-md-6 tracking-left wow fadeInLeft animated" data-wow-delay=".5s">
				<h3>Tracking</h3>
				<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
			</div>
			<div class="col-md-6 tracking-right wow fadeInRight animated" data-wow-delay=".5s">
				<img src="images/map1.png" class="img-responsive" alt="">
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="tracking-botm1">
			
			<div class="col-md-6 tracking-right wow fadeInLeft animated" data-wow-delay=".5s">
				<img src="images/map1.png" class="img-responsive" alt="">
			</div>
			<div class="col-md-6 tracking-left wow fadeInRight animated" data-wow-delay=".5s">
				<h3>Dropping</h3>
				<p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!--- /track ---->
<!--- footer-top ---->
<!--div class="footer-top">
	<div class="container">
		<div class="col-md-6 footer-left wow fadeInLeft animated" data-wow-delay=".5s">
			<h3>Bus Operators</h3>
				<ul>
					<li><a href="bus.html">New York  Charter </a></li>
					<li><a href="bus.html">Washington Charter</a></li>
					<li><a href="bus.html">Los Angeles Charter</a></li>
					<li><a href="bus.html">Chicago Charter</a></li>
					<li><a href="bus.html">Orlando Charter</a></li>
					<li><a href="bus.html">New Orleans Charter</a></li>
					<li><a href="bus.html">Houston Charter</a></li>
					<li><a href="bus.html">Nashville Charter</a></li>
					<li><a href="bus.html">Charlotte Charter</a></li>
					<li><a href="bus.html">Toronto Charter</a></li>
					<li><a href="bus.html">Washington Charter</a></li>
					<li><a href="bus.html">Los Angeles Charter</a></li>
					<li><a href="bus.html">Chicago Charter</a></li>
					<li><a href="bus.html">Orlando Charter</a></li>
					<li><a href="bus.html">New Orleans Charter</a></li>
					<div class="clearfix"></div>
				</ul>
		</div>
		<div class="col-md-6 footer-left wow fadeInRight animated" data-wow-delay=".5s">
			<h3>Bus Routes</h3>
				<ul>
					<li><a href="travels.html">Alabama-California</a></li>
					<li><a href="travels.html">Alaska-Colorado</a></li>
					<li><a href="travels.html">Arizona-Delaware</a></li>
					<li><a href="travels.html">Arkansas-Florida</a></li>
					<li><a href="travels.html">Kansas-Georgia</a></li>
					<li><a href="travels.html">Iowa-Hawaii</a></li>
					<li><a href="travels.html">Indiana-Illinois</a></li>
					<li><a href="travels.html">Illinois-Florida</a></li>
					<li><a href="travels.html">Idaho-Indiana</a></li>
					<li><a href="travels.html">Hawaii-Iowa</a></li>
					<li><a href="travels.html">Georgia-Kansas</a></li>
					<li><a href="travels.html">Florida-Arkansas</a></li>
					<li><a href="travels.html">Delaware-Arizona</a></li>
					<li><a href="travels.html">Colorado-Alaska</a></li>
					<li><a href="travels.html">California-Alabama</a></li>
					<div class="clearfix"></div>
				</ul>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!--- /footer-top ---->
<!---copy-right ---->
<!--div class="copy-right">
	<div class="container">
	
		<div class="footer-social-icons wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
			<ul>
				<li><a class="facebook" href="#"><span>Facebook</span></a></li>
				<li><a class="twitter" href="#"><span>Twitter</span></a></li>
				<li><a class="flickr" href="#"><span>Flickr</span></a></li>
				<li><a class="googleplus" href="#"><span>Google+</span></a></li>
				<li><a class="dribbble" href="#"><span>Dribbble</span></a></li>
			</ul>
		</div>
		<p class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">© 2016 Green Wheels . All Rights Reserved | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
	</div>
</div>
<!--- /copy-right ---->
<!-- sign -->
			<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
						</div>
							<section>
								<div class="modal-body modal-spa">
									<div class="login-grids">
										<div class="login">
											<div class="login-left">
												<ul>
													<li><a class="fb" href="#"><i></i>Sign in with Facebook</a></li>
													<li><a class="goog" href="#"><i></i>Sign in with Google</a></li>
													<li><a class="linkin" href="#"><i></i>Sign in with Linkedin</a></li>
												</ul>
											</div>
											<div class="login-right">
												<form>
													<h3>Create your account </h3>
													<input type="text" value="Name" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Name';}" required="">
													<input type="text" value="Mobile number" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Mobile number';}" required="">
													<input type="text" value="Email id" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Email id';}" required="">	
													<input type="password" value="Password" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Password';}" required="">	
													<input type="submit" value="CREATE ACCOUNT">
												</form>
											</div>
												<div class="clearfix"></div>								
										</div>
											<p>By logging in you agree to our <a href="terms.html">Terms and Conditions</a> and <a href="privacy.html">Privacy Policy</a></p>
									</div>
								</div>
							</section>
					</div>
				</div>
			</div>
<!-- //sign -->
<!-- signin -->
		<div class="modal fade" id="myModal4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content modal-info">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>						
						</div>
						<div class="modal-body modal-spa">
							<div class="login-grids">
								<div class="login">
									<div class="login-left">
										<ul>
											<li><a class="fb" href="#"><i></i>Sign in with Facebook</a></li>
											<li><a class="goog" href="#"><i></i>Sign in with Google</a></li>
											<li><a class="linkin" href="#"><i></i>Sign in with Linkedin</a></li>
										</ul>
									</div>
									<div class="login-right">
										<form>
											<h3>Signin with your account </h3>
											<input type="text" value="Enter your mobile number or Email" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Enter your mobile number or Email';}" required="">	
											<input type="password" value="Password" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Password';}" required="">	
											<h4><a href="#">Forgot password</a></h4>
											<div class="single-bottom">
												<input type="checkbox" id="brand" value="">
												<label for="brand"><span></span>Remember Me.</label>
											</div>
											<input type="submit" value="SIGNIN">
										</form>
									</div>
									<div class="clearfix"></div>								
								</div>
								<p>By logging in you agree to our <a href="terms.html">Terms and Conditions</a> and <a href="privacy.html">Privacy Policy</a></p>
							</div>
						</div>
					</div>
				</div>
			</div>
<!-- //signin -->
<!-- write us -->
			<!--div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
						</div>
							<section>
								<div class="modal-body modal-spa">
									<div class="writ">
										<h4>HOW CAN WE HELP YOU</h4>
											<ul>
												<li class="na-me">
													<input class="name" type="text" value="Name" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Name';}" required="">
												</li>
												<li class="na-me">
													<input class="Email" type="text" value="Email" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Email';}" required="">
												</li>
												<li class="na-me">
													<input class="number" type="text" value="Mobile Number" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Mobile Number';}" required="">
												</li>
												</li>
												<li class="na-me">
													<select id="country" onChange="change_country(this.value)" class="frm-field required sect">
															
														<option value="Booking Issue">Booking Issues</option>
														<!--option value="null">Bus Cancellation</option-->
														<!--option value="Refund">Refund</option>
														<option value="wallet">Wallet</option>														
													</select>
												</li>
												<!--li class="na-me">
													<select id="country" onChange="change_country(this.value)" class="frm-field required sect">
														<option value="null">Select Issue</option> 		
														<option value="null">Booking Issues</option>
														<option value="null">Bus Cancellation</option>
														<option value="null">Refund</option>
														<option value="null">Wallet</option>														
													</select>
												</li-->
												<!--li class="descrip">
													<input class="special" type="text" value="Write Description" onFocus="this.value = '';" onBlur="if (this.value == '') {this.value = 'Write Description';}" required="">
												</li>
													<div class="clearfix"></div>
											</ul>
											<div class="sub-bn">
												<form>
													<button class="subbtn">Submit</button>
												</form>
											</div>
									</div>
								</div>
							</section>
					</div>
				</div>
			</div-->
            <script type="text/javascript" src="../customer/js/creditly.js"></script>
		<script type="text/javascript">
			$(function() {
			  var creditly = Creditly.initialize(
				  '.creditly-wrapper .expiration-month-and-year',
				  '.creditly-wrapper .credit-card-number',
				  '.creditly-wrapper .security-code',
				  '.creditly-wrapper .card-type');

			  $(".creditly-card-form .submit").click(function(e) {
				e.preventDefault();
				var output = creditly.validate();
				if (output) {
				  // Your validated credit card output
				  console.log(output);
				}
			  });
			});
		</script>
<!-- //write us -->
<script src="../customer/js/easy-responsive-tabs.js"></script>
	<script>
		$(document).ready(function () {
			$('#horizontalTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true,   // 100% fit in a container
				closed: 'accordion', // Start closed if in accordion view
				activate: function(event) { // Callback function if tab is switched
				var $tab = $(this);
				var $info = $('#tabInfo');
				var $name = $('span', $info);
				$name.text($tab.text());
				$info.show();
				}
			});
		});
	</script>
</body>
</html>