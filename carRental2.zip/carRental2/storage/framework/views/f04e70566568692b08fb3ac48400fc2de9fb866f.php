<?php /* E:\laravel\carRental2\resources\views/employee/applyleave.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>RentZentric</title>

  <!-- Favicons -->
  <link href="employee/img/favicon.png" rel="icon">
  <link href="employee/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="employee/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="employee/lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="employee/css/style.css" rel="stylesheet">
  <link href="employee/css/style-responsive.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
    <script type="text/javascript">
            $(function () {
                // $('#fromDate').datetimepicker();
                var todayDate = new Date().getDate();
                $('#ldate').datetimepicker({
                  format: 'YYYY-MM-DD',
                  minDate: new Date()
                });
                $('#tdate').datetimepicker({
                  format: 'YYYY-MM-DD',
                  minDate: new Date(new Date().setDate(todayDate + 1))
                });

                $(document).on("change dp.change", "#ldate", function(event){
                  // here `e` is an event itself.
                  // So, `e.target` should be a DOM element of the input field.
                  var endDate = new Date(event.date);
                  endDate.setDate(endDate.getDate() + 1);
                  $('#tdate').data("DateTimePicker").minDate(endDate);
                  var endDateString = ('0' + endDate.getDate()).slice(-2) + '/'
                        + ('0' + (endDate.getMonth()+1)).slice(-2) + '/'
                        + endDate.getFullYear();
        // Set end date
               $('#toate').val(endDateString);
                });
            });
        </script>
    <script type="text/javascript">
           $(function() {
    $( "#ldate" ).datepicker({  maxDate: new Date });
  });
        </script>
<script>
	function validate_fileupload(fileName)
{
    var allowed_extensions = new Array("jpg","png");
    var file_extension = fileName.split('.').pop().toLowerCase(); // split function will split the filename by dot(.), and pop function will pop the last element from the array which will give you the extension as well. If there will be no extension then it will return the filename.

    for(var i = 0; i <= allowed_extensions.length; i++)
    {
        if(allowed_extensions[i]==file_extension)
        {
            return true; // valid file extension
        }
    }
		$('#idproof').val(null);
    return false;
}
	function isNumberKey(evt)
	{
		var charCode=(evt.which)?evt.which:event.KeyCode;
		if(charCode!=46 && charCode>31 && (charCode<48||charCode>57))
		{
			// alert("Enter Number");
			return false;
			}
			return true;
		  }
		function lettersOnly() 
{
            var charCode = event.keyCode;

            if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || charCode == 8)
                return true;
            else {
							// alert("Enter chararctes only");
                return false;
						}
		
}
function validateForm(){
	return validateemail() && confirmPasword();
}
function confirmPasword() {
	//alert("Password required");  
	var pswd1=document.getElementById("pswd").value;
	var pswd2=document.getElementById("pswdConfirm").value;
	if (pswd1 === "") {
		$('#errMsgPswrd1').html('Password required'); 
		alert("Password required");  
		return false;
	}	else if (pswd1 !== pswd2) {
		$('#errMsgPswrd2').html('Password mismatch'); 
		return false;
	} else {
		return true;
	}
}
function validateemail()  
{  
	var x=document.getElementById("emailId").value;
	console.log('email', x);
	// alert(x);
	if (!validateEmailAddress(x)){ 
		$('#errMsgEmail').html('Invalid Email-id'); 
		//alert("Please enter a valid e-mail address");  
		return false;  

	} else{
		$('#errMsgEmail').html(''); 
		return true;
	}  
}
function validateEmailAddress(address) {
  let isValid = true;
   const emailPattern =  /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
   isValid = emailPattern.test(address);
   return isValid;
}  

</script>		
  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
  <style>

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 420px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=date] {
  width:420px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
</style>
</style>
 
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>Rent<span>Zentric</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
          <!-- settings start -->
          <li class="dropdown">
            <!--a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-tasks"></i>
              <span class="badge bg-theme">4</span>
              </a>
            <ul class="dropdown-menu extended tasks-bar">
              <div class="notify-arrow notify-arrow-green"></div>
              <li>
                <p class="green">You have 4 pending tasks</p>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Dashio Admin Panel</div>
                    <div class="percent">40%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                      <span class="sr-only">40% Complete (success)</span>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Database Update</div>
                    <div class="percent">60%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
                      <span class="sr-only">60% Complete (warning)</span>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Product Development</div>
                    <div class="percent">80%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                      <span class="sr-only">80% Complete</span>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Payments Sent</div>
                    <div class="percent">70%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%">
                      <span class="sr-only">70% Complete (Important)</span>
                    </div>
                  </div>
                </a>
              </li>
              <li class="external">
                <a href="#">See All Tasks</a>
              </li>
            </ul>
          </li>
          <!-- settings end -->
          <!-- inbox dropdown start-->
          <!--li id="header_inbox_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-envelope-o"></i>
              <span class="badge bg-theme">5</span>
              </a>
            <ul class="dropdown-menu extended inbox">
              <div class="notify-arrow notify-arrow-green"></div>
              <li>
                <p class="green">You have 5 new messages</p>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-zac.jpg"></span>
                  <span class="subject">
                  <span class="from">Zac Snider</span>
                  <span class="time">Just now</span>
                  </span>
                  <span class="message">
                  Hi mate, how is everything?
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-divya.jpg"></span>
                  <span class="subject">
                  <span class="from">Divya Manian</span>
                  <span class="time">40 mins.</span>
                  </span>
                  <span class="message">
                  Hi, I need your help with this.
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-danro.jpg"></span>
                  <span class="subject">
                  <span class="from">Dan Rogers</span>
                  <span class="time">2 hrs.</span>
                  </span>
                  <span class="message">
                  Love your new Dashboard.
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-sherman.jpg"></span>
                  <span class="subject">
                  <span class="from">Dj Sherman</span>
                  <span class="time">4 hrs.</span>
                  </span>
                  <span class="message">
                  Please, answer asap.
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">See all messages</a>
              </li>
            </ul>
          </li>
          <!-- inbox dropdown end -->
          <!-- notification dropdown start-->
          <!--li id="header_notification_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-bell-o"></i>
              <span class="badge bg-warning">7</span>
              </a>
            <ul class="dropdown-menu extended notification">
              <div class="notify-arrow notify-arrow-yellow"></div>
              <li>
                <p class="yellow">You have 7 new notifications</p>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-danger"><i class="fa fa-bolt"></i></span>
                  Server Overloaded.
                  <span class="small italic">4 mins.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-warning"><i class="fa fa-bell"></i></span>
                  Memory #2 Not Responding.
                  <span class="small italic">30 mins.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-danger"><i class="fa fa-bolt"></i></span>
                  Disk Space Reached 85%.
                  <span class="small italic">2 hrs.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-success"><i class="fa fa-plus"></i></span>
                  New User Registered.
                  <span class="small italic">3 hrs.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">See all notifications</a>
              </li>
            </ul>
          </li>
          <!-- notification dropdown end -->
        </ul-->
        <!--  notification end -->
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
         <!--li><a href="employee.profile"><img src="employee/img/user1.png" width="60" height="60"/></a></li-->
          <li><a class="logout" href="/index">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="employee/img/h.png" class="img-circle" width="80"></a></p>
          <h5 class="centered"><font color="#0033FF">
                            <?php if(session()->has('email')): ?>
<h4><?php echo e(session()->get('email')); ?></h4>
<?php endif; ?></h5></font>
</center></h5>
          <li class="mt">
            <a href="employee.index" class="active">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
          </li>
           <li class="sub-menu">
            <a href="employee.profile">
              <i class="fa fa-user-circle"></i>
              <span>Profile</span>
              </a>
          </li>
         
          <li class="sub-menu">
            <a href="employee.carlist">
              <i class="fa fa-car"></i>
              <span>Car List</span>
              </a>
           
          </li>
         <li class="sub-menu">
            <a  href="employee.workingh">
              <i class="fa fa-book"></i>
              <span>Working Details</span>
              </a>
            
          </li>
           <li class="sub-menu">
            <a href="employee.leave">
              <i class="fa fa-tasks"></i>
              <span>Leave</span>
              </a>
            <ul class="sub">
              <li><a href="employee.applyleave">Apply Leave</a></li>
              <li><a href="employee.leaves">Leave Status</a></li>
              
            </ul>
          </li>

          <!--li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-th"></i>
              <span>Booking History</span>
              </a>
           
          </li-->
         
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
      
        <h3><i class="fa fa-angle-right"></i><font color="#FF0000">Apply Leave</font></h3>
        <div class="row mt">
          <div class="col-lg-12">
         <br> 
 <form action="employee.applyleave1" method="post" enctype="multipart/form-data" id="adcar" >
  <?php echo csrf_field(); ?>
   <!--div class="row">
      <div class="col-25">
        <label for="fname">Email Id</label>
      </div>
      < class="col-75">
        <input type="text" id="email" name="email"  autocomplete="off" maxlength="9"  value=" <?php if(session()->has('email')): ?>
<?php echo e(session()->get('email')); ?>" <?php endif; ?> disabled>
      </div>
    </div-->
    <div class="row">
      <div class="col-25">
        <label for="fname"><font color="#0000CC">Leave Date</font></label>
      </div>
      <?php  $date=date('Y-m-d'); ?>
    <div class="col-75">
      
        <input type="date" min="<?php echo$date;?>" max="2019-12-31"  name="ldate"   required>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname"><font color="#0000CC">Session</font></label>
      </div>
      <div class="col-75"  >
         <select  for="recipient-name" name="ts" style="width: 420px" id="session" required>
                            <option value="FN">FN</option>
  									<option value="AN">AN</option>
 									 <option value="FULLDAY">FULL DAY</option>
                                      </select>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname"><font color="#0000CC">Reason</font></label>
      </div>
      <div class="col-75">
        <input type="text" id="reason" name="reason" minlength="3" title="enter minmum three chararcters"  onKeyPress="return lettersOnly(event)"  autocomplete="off"  required>
      </div>
    </div>
       
  
   
    <div class="row">
      <input type="submit" value="APPLY">
    </div>
  </form>
 
          </div>
        </div>
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
       
        <div class="credits">
        </div>
          <!--
            You are NOT allowed to delete the credit link to TemplateMag with free version.
            You can delete the credit link only if you bought the pro version.
            Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
            Licensing information: https://templatemag.com/license/
          -->
        
        </div>
        <a href="blank.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="employee/lib/jquery/jquery.min.js"></script>
  <script src="employee/lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="employee/lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="employee/lib/jquery.ui.touch-punch.min.js"></script>
  <script class="include" type="text/javascript" src="employee/lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="employee/lib/jquery.scrollTo.min.js"></script>
  <script src="employee/lib/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="employee/lib/common-scripts.js"></script>
  <!--script for this page-->

</body>

</html>
