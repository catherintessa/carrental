<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Empw extends Model
{
    public $fillable=['empid','date_from','date_to','route_from','route_to','status'];
}
