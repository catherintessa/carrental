<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Adcar extends Model
{
   public $fillable=['car_regno','car_brand','car_model','car_ftype','car_nofs','car_actype','car_rent','car_image'];
}
