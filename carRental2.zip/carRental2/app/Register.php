<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Register extends Model
{
     public $fillable=['fname','lname','place','district','cno','pin','photo','email','type'];
}
