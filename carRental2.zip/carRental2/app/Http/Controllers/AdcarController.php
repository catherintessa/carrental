<?php

namespace App\Http\Controllers;

use App\Adcar;
use Illuminate\Http\Request;
use DB;
use Carbon\Carbon;

class AdcarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       // $car=Adcar::all();
        $qry="SELECT * from  adcars where status='0' or status='1'" ;
        $car= DB::select($qry);
        return view ('admin.carlist',compact('car'));
    }
    public function index1()
    {
        $car=Adcar::where('status',1)->get();
        return view ('customer.carlist1',compact('car'));
    }
    public function index6()
    {
        //$car=Adcar::where('status',2)->get();
        $qry="SELECT * from  adcars r INNER JOIN carowner b ON r.car_regno=b.car_regno ";
        $car= DB::select($qry);
        return view ('admin.newcar',compact('car'));
    }
public function index2()
    {
		 $car=Adcar::where('status',1)->get();
       
        return view ('employee.carlist',compact('car'));
    }
    public function index3()
    {
		 $car=Adcar::where('status',1)->get();
       
        return view ('customer.search',compact('car'));
    }
    public function index5()
    {
		 $car=Adcar::where('status',1)->get();
       
        return view ('customer.remove',compact('car'));
    }
 public function remove1($car_regno)
    {
		
        
            $car= DB::table('Adcars')->where(['car_regno'=>$car_regno])->get();
            // foreach($car as $object)
            // {
             return view("customer.display",compact('car'));
            //}
        

    }
    
   
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function create(Request $request)
    {
        //$place= $request->get('place');
        $from= $request->get('fdate');
        $to= $request->get('tdate');
        $nofs= $request->get('nofs');
        $rent= $request->get('rent');
        $actype= $request->get('actype');
        //echo $from;
        //echo $to;
        //$car_model=$request->get('car_model');
        //$model= $request->get('model');
        //if($model==""){
            //$model= '%';
        //}
        //$car =DB::select('select adcars.* ,adcars.car_regno not in (select car_regno from booking where (? between booking.date_from and booking.date_to or ? between booking.date_from and booking.date_to or (? <= booking.date_from and ? >= booking.date_to)) and status=? )',[$from,$to,1]);
        //$car=DB::select('select * from adcars  where adcars.car_regno not in (select car_regno from booking)');
        // $car=DB::select("select * from adcars  where adcars.car_regno not in (select car_regno from booking)
        // UNION 
        // SELECT booking.car_regno
        // FROM booking 
        // WHERE (booking.datefrom < '$from' AND booking.dateto < '$to')
        // OR (booking.datefrom > '$from' AND tbl_booking.dateto > '$to')");

        $qry = "select * from adcars as a where a.status='1' and a.car_nofs='$nofs' and a.car_actype='$actype'  and  a.car_regno not in (SELECT b.car_regno
        FROM booking as b
        WHERE (( b.date_from >= '$from' and b.date_from <= '$to' and b.c_status='0')
              or (b.date_to <= '$to' and b.date_to >= '$from' and b.c_status='0')) 
              or (b.date_from <= '$from' and b.date_to >= '$to'and b.c_status='0' ))";
        $car= DB::select($qry);

       
   

       //$car=DB::select("SELECT *
       //FROM adcars  LEFT JOIN booking 
       //ON adcars.car_regno=booking.car_regno
       //WHERE (booking.car_regno IS NULL)
       //UNION 
      // SELECT booking.car_regno
       //FROM booking 
       //WHERE (booking.date_from < '$fdate' AND booking.date_to < '$tdate')
       //OR (booking.date_from > '$fdate' AND booking.date_to > '$tdate')");
       
           
        //$pagination = Paginator::make($vehicles, count($vehicles), 10);
        
        return view('customer.remove',compact('car','from','to'));

    }
    public function create1(Request $request)
    {
        //$place= $request->get('place');
        $from= $request->get('fdate');
        $to= $request->get('tdate');
        
       
        //$model= $request->get('model');
        //if($model==""){
            //$model= '%';
        //}
        //$car =DB::select('select adcars.* ,adcars.car_regno not in (select car_regno from booking where (? between booking.date_from and booking.date_to or ? between booking.date_from and booking.date_to or (? <= booking.date_from and ? >= booking.date_to)) and status=? )',[$from,$to,1]);
        //$car=DB::select('select * from adcars  where adcars.car_regno not in (select car_regno from booking)');
        // $car=DB::select("select * from adcars  where adcars.car_regno not in (select car_regno from booking)
        // UNION 
        // SELECT booking.car_regno
        // FROM booking 
        // WHERE (booking.datefrom < '$from' AND booking.dateto < '$to')
        // OR (booking.datefrom > '$from' AND tbl_booking.dateto > '$to')");

        $qry = "select * from adcars as a where a.car_regno not in (SELECT b.car_regno
        FROM booking as b
        WHERE ((b.date_from >= '$from' and b.date_from <= '$to')
              or (b.date_to <= '$to' and b.date_to >= '$from')) 
              or (b.date_from <= '$from' and b.date_to >= '$to'))";
        $car= DB::select($qry);
        $start = Carbon::parse($from)->format('Y/m/d');
        $end =  Carbon::parse($to)->format('Y/m/d');
    
        $days = $end->diffInDays($start);
        /*$days=date_diff($end,$start);*/
        echo $days;
        
       //$car=DB::select("SELECT *
       //FROM adcars  LEFT JOIN booking 
       //ON adcars.car_regno=booking.car_regno
       //WHERE (booking.car_regno IS NULL)
       //UNION 
      // SELECT booking.car_regno
       //FROM booking 
       //WHERE (booking.date_from < '$fdate' AND booking.date_to < '$tdate')
       //OR (booking.date_from > '$fdate' AND booking.date_to > '$tdate')");
       
           
        //$pagination = Paginator::make($vehicles, count($vehicles), 10);
        
        return view('customer.book',compact('car','from','to'));

    }
	 public function change($id)
    {
        $car = Adcar::find($id);
        // foreach($car as $object)
        // {
        return view("admin.edit",compact('car'));
        //}
    }
    public function book(Request $request,$car_regno)
    {
      $fdate = $request->input('fdate');
      $tdate = $request->input('tdate');
      // echo $fdate;
      // echo $tdate;

        $car = DB::table('adcars')->where(['car_regno'=>$car_regno])->get();
        // foreach($car as $object)
        // {
        return view('customer.book',compact('car','fdate','tdate'));
        //}
    }
    
    public function update(Request $request,$id)
    {
   $car_regno = $request->input('car_regno');
	 //$car_brand=$request->input('car_brand');
//$car_model = $request->input('car_model');
$car_image = $request->input('car_image');
//$car_ftype = $request->input('car_ftype');
$car_rent=$request->input('car_rent');
 $filename= $request->car_image->getClientOriginalName();
  $request->car_image->storeAs('public/upload',$filename);
$regid=db::table('adcars')->where('car_regno',"=",$car_regno)->get();
		
			
$data=array("car_rent"=>$car_rent,"car_image"=>$filename);
DB::table('adcars')->where('id',"=",$id)->update($data);
//echo "<script>";
//echo 'alert("successfully edited car details")';
//echo" </script>";
//return view('/index');
		return redirect("admin.carlist");

		}

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $car_regno = $request->input('car_regno');
        $car_model = $request->input('car_model');
        $car_brand = $request->input('car_brand');
        $ftype = $request->input('ftype');
        $nofs = $request->input('nofs');
        $actype = $request->input('actype');
        $rent = $request->input('rent');
        $car_image  = $request->input('car_image');
        //$photo=$request->input('photo');
	 
	//$email=$request->input('email');
	//$image = $request->file('image');
       
           
               $filename= $request->car_image->getClientOriginalName();
               //Storage::put('public\upload\',$filename,file_get_contents($request->file('photo')->getRealPath()));
              $request->car_image->storeAs('public/upload',$filename);
        //$reg_id=$request->input('reg_id');
       
        //$u_type=$request->get('u_type');
        $check=DB::table('adcars')->where(['car_regno'=>$car_regno])->get();
    if(count($check)>0)
   {
    echo "<script>";
    echo 'alert("already exited register number")';
   echo" </script>";
   return view('admin.addcar');
    }
    else
    {
        $s=1;
      $data=array('car_regno'=>$car_regno,'car_brand'=>$car_brand,'car_model'=>$car_model,'car_ftype'=>$ftype,'car_nofs'=>$nofs,'car_actype'=>$actype,'car_rent'=>$rent,'car_image'=>$filename,'status'=>$s);
    DB::table('adcars')->insert($data);
	echo "<script>";
	  echo 'alert("successfully adding car details")';
	 echo" </script>";
	 return view('admin.index');
       
    }
    }
    
    /**
     * Display the specified resource.
     *
     * @param  \App\Adcar  $adcar
     * @return \Illuminate\Http\Response
     */
    public function show(Adcar $adcar)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Adcar  $adcar
     * @return \Illuminate\Http\Response
     */
    public function edit(Adcar $adcar)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Adcar  $adcar
     * @return \Illuminate\Http\Response
     */
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Adcar  $adcar
     * @return \Illuminate\Http\Response
     */
	 public function approve($id)
   {
      $value=adcar::where('id','=',$id)->get();
      foreach ($value as $object)
      {
         if($object->status== '1')
         {
            adcar::where('id',$id)
            ->update(['status' => 0]);
         }
         else
         {
            adcar::where('id',$id)
            ->update(['status'=> 1]);
         }
      }
      return redirect('admin.carlist');
   }
   public function approve3($b_id)
   {
    $value = DB::table('booking')->where(['b_id'=>$b_id])->get();
    foreach ($value as $object)
    {
       if($object->p_status== '0')
       {
         $value1 = DB::table('booking')->where('b_id',$b_id)
          ->update(['p_status' => 1]);
       }
       else
         {
            $value1 = DB::table('booking')->where('b_id',$b_id)
            ->update(['p_status' => 0]);
         }
      }
      return redirect('admin.bookingh');
   }
   public function approve1($id)
   {
      $value=adcar::where('car_regno','=',$id)->get();
      foreach ($value as $object)
      {
         if($object->status== '2')
         {
            adcar::where('car_regno',$id)
            ->update(['status' => 1]);
         }
         else
         {
            adcar::where('car_regno',$id)
            ->update(['status'=> 2]);
         }
      }
      return redirect('admin.newcar');
   }
   public function approve4($b_id)
   {
    $value = DB::table('booking')->where(['b_id'=>$b_id])->get();
      foreach ($value as $object)
      {
         if($object->con_status== '0')
         {
            
          $value1 = DB::table('booking')->where('b_id',$b_id)
          ->update(['con_status' => 1]);
         }
         
      }
      return redirect('admin.bookingh');
   }
    public function destroy($id)
    {
        DB::delete('delete from adcars where id = ?',[$id]);
		//return view('Admin.ViewDoctor');
		return redirect("admin.carlist");
    }
    public function search1(Request $req)
    {
       $search=$req->input('search');
       $car=DB::select("select * from adcars where car_brand='$search' and status='1' or status='0'");  
   return view('admin.search1',compact('car'));
   //return redirect('/searchemployees');
     }
     public function search2(Request $req)
     {
        $search=$req->input('search');
        //$car=DB::select("select * from adcars where car_model='$search'");
        $qry="SELECT * from  adcars a INNER JOIN booking b ON a.car_regno=b.car_regno  where b.email='$search'";
        $car= DB::select($qry);
    return view('admin.search2',compact('car'));
    //return redirect('/searchemployees');
      }
      public function search3(Request $req)
     {
        $search=$req->input('search');
        //$car=DB::select("select * from adcars where car_model='$search'");
        $qry="SELECT * from  adcars a INNER JOIN booking b ON a.car_regno=b.car_regno where b.email='$search'";
        $car= DB::select($qry);
    return view('admin.search3',compact('car'));
    //return redirect('/searchemployees');
      }
     public function book1()
     {
        if(session()->has('email'))
        {
          $x=session()->get('email');
        }
         //return $x;
         $fd=date("Y/m/d");
         //echo $fd;
         //$qry="SELECT a.car_brand,a.car_model,b.date_from,b.date_to  from adcars a JOIN booking b ON a.car_regno=b.car_regno AND b.email=$x ";
        
         $qry="SELECT * from  adcars a INNER JOIN booking b  ON a.car_regno=b.car_regno   where b.email='$x' and b.c_status='0'";
         // $x="select from booking as b where b.b_id in inner join payment c on b.b_id=c.b_id ";
   //$a=DB::select("select b_id from  booking as b where b.b_id in (select c.b_id from payment  as c");
  //echo $a;
   //echo $x1;
  //$a = DB::select('SELECT * FROM booking');
   
         //$y="select * from payments";
        // $status;
        // foreach ($x as $x){
         // $check=DB::table('payments')->where(['b_id'=>$x])->get();
          //if(count($check)>0)
          //{
            //$status=1;
         // }
         //else{
           //$status=0;
         //}
        //}
         
         $car= DB::select($qry);

         //$car = DB::table('booking')->where(['email'=>$x])->get($qry);
          return view ('customer.bookingh',compact('car'));
     
     }
     public function book5($id)
     {
        if(session()->has('email'))
        {
          $x=session()->get('email');
        }
         //return $x;
         $fd=date("d/m/y");
         //echo $fd;
         //$qry="SELECT a.car_brand,a.car_model,b.date_from,b.date_to  from adcars a JOIN booking b ON a.car_regno=b.car_regno AND b.email=$x ";
        
         $qry="SELECT * from  booking where b_id='$id'";
         // $x="select from booking as b where b.b_id in inner join payment c on b.b_id=c.b_id ";
   //$x="select b_id from booking";
         //$y="select * from payments";
        // $status;
        // foreach ($x as $x){
         // $check=DB::table('payments')->where(['b_id'=>$x])->get();
          //if(count($check)>0)
          //{
            //$status=1;
         // }
         //else{
           //$status=0;
         //}
        //}
         
         $car= DB::select($qry);

         //$car = DB::table('booking')->where(['email'=>$x])->get($qry);
          return view ('customer.payment',compact('car','fd','status'));
     
     }
     public function book2()
     {
         //return $x;
         
         //$qry="SELECT a.car_brand,a.car_model,b.date_from,b.date_to  from adcars a JOIN booking b ON a.car_regno=b.car_regno AND b.email=$x ";
         $qry="SELECT * from  adcars a INNER JOIN booking b ON a.car_regno=b.car_regno where b.c_status='0' ";
         
         $car= DB::select($qry);

         //$car = DB::table('booking')->where(['email'=>$x])->get($qry);
          return view ('admin.bookingh',compact('car'));
     
     }
     public function book3($id)
     {
         //return $x;
         
         //$qry="SELECT a.car_brand,a.car_model,b.date_from,b.date_to  from adcars a JOIN booking b ON a.car_regno=b.car_regno AND b.email=$x ";
         $qry="SELECT * from  adcars where car_regno='$id' ";
         
         $car= DB::select($qry);

         //$car = DB::table('booking')->where(['email'=>$x])->get($qry);
          return view ('customer.view',compact('car'));
     
     }
     public function book4($id)
     {
         //return $x;
         
         //$qry="SELECT a.car_brand,a.car_model,b.date_from,b.date_to  from adcars a JOIN booking b ON a.car_regno=b.car_regno AND b.email=$x ";
         $qry="SELECT * from  registers where email='$id' ";
         
         $car= DB::select($qry);

         //$car = DB::table('booking')->where(['email'=>$x])->get($qry);
          return view ('admin.view',compact('car'));
     
     }
     public function car($id)
     {
         //return $x;
         
         //$qry="SELECT a.car_brand,a.car_model,b.date_from,b.date_to  from adcars a JOIN booking b ON a.car_regno=b.car_regno AND b.email=$x ";
         $qry="SELECT * from  registers r INNER JOIN carowner b ON r.email=b.email where b.car_regno='$id' ";
         
         $car= DB::select($qry);

         //$car = DB::table('booking')->where(['email'=>$x])->get($qry);
          return view ('admin.carowner',compact('car'));
     
     }
     public function status()
    {
       if(session()->has('email'))
       {
         $x=session()->get('email');
       }
        //return $x;
        $qry="SELECT * from  adcars  a INNER JOIN carowner b ON a.car_regno=b.car_regno where b.email='$x' ";
         //$result=Leave::where('email','=',$x)->get();
         $car= DB::select($qry);
       return view('carowner.status',compact('car'));
    
    }
    public function bookingh()
    {
       if(session()->has('email'))
       {
         $x=session()->get('email');
       }
        //return $x;
        $qry="SELECT a.email,a.car_regno,a.date_from,a.date_to from  booking  a INNER JOIN carowner b ON a.car_regno=b.car_regno where b.email='$x' ";
         //$result=Leave::where('email','=',$x)->get();
         //$qry1="select status from payments a INNER JOIN booking b where b.b_id=a.b_id";
        // $b_id="select b_id from booking";
        // echo $b_id;
      
   // $check=DB::table('payments')->where(['b_id'=>$b_id])->get();

         
         $car= DB::select($qry);
       return view('carowner.bookingh',compact('car','a'));
    
    }
    public function cview($id)
    {
      
        //return $x;
        $qry="SELECT * from registers  where email='$id' ";
         //$result=Leave::where('email','=',$x)->get();
         $car= DB::select($qry);
       return view('carowner.view',compact('car'));
    
    }
    public function viewcar()
    {
       if(session()->has('email'))
       {
         $x=session()->get('email');
       }
        //return $x;
        $qry="SELECT * from  adcars  a INNER JOIN carowner b ON a.car_regno=b.car_regno where b.email='$x' ";
         //$result=Leave::where('email','=',$x)->get();
         $car= DB::select($qry);
       return view('carowner.carlist',compact('car'));
    
    }
    public function store3(Request $request)
   {
       if(session()->has('email'))
       {
         $x=session()->get('email');
       }
       $car_regno = $request->input('car_regno');
       $car_model = $request->input('car_model');
       $car_brand = $request->input('car_brand');
       $ftype = $request->input('ftype');
       $nofs = $request->input('nofs');
       $actype = $request->input('actype');
       $rent = $request->input('rent');
       $car_image  = $request->input('car_image');
       //$photo=$request->input('photo');
    
   //$email=$request->input('email');
   //$image = $request->file('image');
      
          
              $filename= $request->car_image->getClientOriginalName();
              //Storage::put('public\upload\',$filename,file_get_contents($request->file('photo')->getRealPath()));
             $request->car_image->storeAs('public/upload',$filename);
       //$reg_id=$request->input('reg_id');
      
       //$u_type=$request->get('u_type');
       $check=DB::table('adcars')->where(['car_regno'=>$car_regno])->get();
   if(count($check)>0)
  {
   echo "<script>";
   echo 'alert("already exited register number")';
  echo" </script>";
  return view('carowner.index');
   }
   else
   {
       $s=2;
     $data=array('car_regno'=>$car_regno,'car_brand'=>$car_brand,'car_model'=>$car_model,'car_ftype'=>$ftype,'car_nofs'=>$nofs,'car_actype'=>$actype,'car_rent'=>$rent,'car_image'=>$filename,'status'=>$s);
   DB::table('adcars')->insert($data);
   $data1=array('car_regno'=>$car_regno,'email'=>$x);
   DB::table('carowner')->insert($data1);
   echo "<script>";
     echo 'alert("successfully adding car details")';
    echo" </script>";
    return view('carowner.index');
    
      
   }

   }
   public function store1(Request $request)
    {
      $eid = $request->input('eid');
       $df = $request->input('date_from');
       $dt = $request->input('date_to');
       $rf = $request->input('route_from');
       $rt = $request->input('route_to');
      
      
       //$u_type=$request->get('u_type');
       
       $s=1;
     $data=array('empid'=>$eid,'date_from'=>$df,'date_to'=>$dt,'route_from'=>$rf,'route_to'=>$rt,'status'=>$s);
   DB::table('empws')->insert($data);
   
   echo "<script>";
	 echo 'alert("successfuly enterd working details")';
	echo" </script>";
	return redirect('admin.clist');
   }
}
