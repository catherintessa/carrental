<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class emController extends Controller
{
    public function index()
    {
        return view('employee.index');
    }
	public function carlist()
    {
        return view('employee.carlist');
    }

public function leave()
    {
        return view('employee.leave');
    }
	public function lock_screen()
    {
        return view('employee.lock_screen');
    }
    public function applyleave()
    {
        return view('employee.applyleave');
    }
    public function leaves()
    {
        return view('employee.leaves');
    }
	}