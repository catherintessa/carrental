<?php

namespace App\Http\Controllers;

use App\Empw;
use Illuminate\Http\Request;

class EmpwController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Empw  $empw
     * @return \Illuminate\Http\Response
     */
    public function show(Empw $empw)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Empw  $empw
     * @return \Illuminate\Http\Response
     */
    public function edit(Empw $empw)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Empw  $empw
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Empw $empw)
    {
        //
    }
	 public function work()
  {
     if(session()->has('email'))
     {
       $x=session()->get('email');
     }
      //return $x;
       $result=empw::where('empid','=',$x)->get();
     return view('employee.workingh',compact('result'));
  
  }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Empw  $empw
     * @return \Illuminate\Http\Response
     */
    public function destroy(Empw $empw)
    {
        //
    }
}
