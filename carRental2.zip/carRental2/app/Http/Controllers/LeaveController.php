<?php

namespace App\Http\Controllers;

use App\Leave;
use Illuminate\Http\Request;
use DB;

class LeaveController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function leave()
    {
       // $car=Leave::where status="0";
        $car=Leave::select('id','email','date','times','reason','status')->get();
        return view ('admin.leave',compact('car'));
    }
    public function leaves()
    {
       if(session()->has('email'))
       {
         $x=session()->get('email');
       }
        //return $x;
         $result=Leave::where('email','=',$x)->get();
       return view('employee.leaves',compact('result'));
    
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if(session()->has('email'))
        {
          $x=session()->get('email');
        }
      
       $ldate = $request->input('ldate');
       $ts = $request->input('ts');
       $reason = $request->input('reason');
      
      
      
       //$u_type=$request->get('u_type');
       
       $s=0;
     $data=array('email'=>$x,'date'=>$ldate,'times'=>$ts,'reason'=>$reason,'status'=>$s);
   DB::table('leaves')->insert($data);
   //return redirect('employee.index');
   echo "<script>";
	 echo 'alert("successfuly applied for leave")';
	echo" </script>";
	 return view('employee.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Leave  $leave
     * @return \Illuminate\Http\Response
     */
    public function show(Leave $leave)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Leave  $leave
     * @return \Illuminate\Http\Response
     */
    public function edit(Leave $leave)
    {
        //
    }
    public function approve1($id)
    {
       $value=Leave::where('id','=',$id)->get();
       foreach ($value as $object)
       {
          if($object->status=='0')
          {
             Leave::where('id',$id)
             ->update(['status' => 1]);
          }
          else
          {
             Leave::where('id',$id)
             ->update(['status'=> 0]);
          }
          
       }
       return redirect('admin.leave');
    }
   
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Leave  $leave
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Leave $leave)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Leave  $leave
     * @return \Illuminate\Http\Response
     */
    public function destroy(Leave $leave)
    {
        //
    }
}
