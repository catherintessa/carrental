<?php

namespace App\Http\Controllers;

use App\Me;
use Illuminate\Http\Request;
use DB;

class MeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $name = $request->input('name');
    $email = $request->input('email');
    $mob = $request->input('mobile');
	$data=array('name'=>$name,'email'=>$email,'mobile'=>$mob);
DB::table('me')->insert($data);

echo "<script>";
echo 'alert("successfuly send message")';
echo" </script>";
return redirect('/index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Me  $me
     * @return \Illuminate\Http\Response
     */
    public function show(Me $me)
    {
    
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Me  $me
     * @return \Illuminate\Http\Response
     */
    public function edit(Me $me)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Me  $me
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Me $me)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Me  $me
     * @return \Illuminate\Http\Response
     */
    public function destroy(Me $me)
    {
        //
    }
}
