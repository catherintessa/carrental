<?php

namespace App\Http\Controllers;

use App\Register;
use APP\empws;
use Illuminate\Http\Request;
use DB;
use Hash;

class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $customer=Register::select('id','fname','email','place','photo','cno')->where('type',2)->get();
       
        return view ('admin.clist',compact('customer'));
    }
	public function change($email)
    {
        $value = DB::table('registers')->where(['email'=>$email])->get();
        // foreach($car as $object)
        // {
        return view("customer.edit",compact('value'));
        //}
    }
	public function change1($email)
    {
        $value = DB::table('registers')->where(['email'=>$email])->get();
        // foreach($car as $object)
        // {
        return view("employee.edit",compact('value'));
        //}
    }
    public function change2($email)
    {
        $value = DB::table('registers')->where(['email'=>$email])->get();
        // foreach($car as $object)
        // {
        return view("carowner.edit",compact('value'));
        //}
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
	public function profile()
    {
       if(session()->has('email'))
       {
         $x=session()->get('email');
       }
        //return $x;
         $result=Register::where('email','=',$x)->get();
       return view('employee.profile',compact('result'));
    
    }
    public function profile1()
    {
       if(session()->has('email'))
       {
         $x=session()->get('email');
       }
        //return $x;
         $result=Register::where('email','=',$x)->get();
       return view('carowner.profile',compact('result'));
    
    }
    public function index4($id)
    {
        $b_id=$id;
       if(session()->has('email'))
       {
         $x=session()->get('email');
       }
       $fd=date("d/m/y");
        //return $x;
         $customer=Register::where('email','=',$x)->get();
       return view('customer.payment2',compact('customer','fd','b_id'));
    
    }
	public function viewprofile()
    {
       if(session()->has('email'))
       {
         $x=session()->get('email');
       }
        //return $x;
         $result=Register::where('email','=',$x)->get();
       return view('customer.profile',compact('result'));
    
    }
   
 
    
   public function index1($email)
   {
       
       $car = Register::where('email','=',$email)->get();
       return view("admin.empw",compact('car'));
       //}
   
   }
   public function vieww($email)
   {
    $car=DB::select("select * from empws where empid='$email'");  
    return view('admin.vieww',compact('car'));
       
       //}
   
   }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $utype = $request->input('usertype');
    $fname = $request->input('fname');
    $lname = $request->input('lname');
    $place = $request->input('place');
    $district = $request->input('district');
    $cno = $request->input('cno');
    $pin = $request->input('pin');
   
    $photo=$request->input('photo');
	 
	//$email=$request->input('email');
	//$image = $request->file('image');
       
           
               $filename= $request->photo->getClientOriginalName();
               //Storage::put('public\upload\',$filename,file_get_contents($request->file('photo')->getRealPath()));
              $request->photo->storeAs('public/upload',$filename);
    $email = $request->input('email');
    $password = $request->input('password');
    //$reg_id=$request->input('reg_id');
   
    //$u_type=$request->get('u_type');
    $check=DB::table('logins')->where(['email'=>$email])->get();
    if(count($check)>0)
   {
    echo "<script>";
    echo 'alert("already exited emailid,please register again")';
   echo" </script>";
   return view('/index');
    }
    else
    {
    
        
 if($utype=="customer")
 {
$type=1;  
$data=array('fname'=>$fname,'lname'=>$lname,'place'=>$place,'district'=>$district,'cno'=>$cno,'pin'=>$pin,'photo'=>$filename,'email'=>$email,'type'=>$type);
DB::table('registers')->insert($data);
}
else if($utype=="employee")
{
$type=2; 
$data=array('fname'=>$fname,'lname'=>$lname,'place'=>$place,'district'=>$district,'cno'=>$cno,'pin'=>$pin,'photo'=>$filename,'email'=>$email,'type'=>$type);
DB::table('registers')->insert($data);
}
else{
$type=3;  
 $data=array('fname'=>$fname,'lname'=>$lname,'place'=>$place,'district'=>$district,'cno'=>$cno,'pin'=>$pin,'photo'=>$filename,'email'=>$email,'type'=>$type);
DB::table('registers')->insert($data);
}

    
    //$unm=$request->input('email');
    //$check=DB::table('logins')->where(['login_email'=>$unm])->get();
    //if(count($check)==0)
    //{
        //$users=new Registers(['fname'=>$request->get('fname')]);
        //$users->save();
        //$insertedId = $users->reg_id;
        //$utype = $request->input('usertype');
        //$unm=$request->input('email');
        //$password=$request->input('password');
        //$usertype=$request->input('utype));
        //$cpwd=$request->input('cpassword'); 
        //$insertedId=registers::max('regid');
        //dd($insertedId);
        if($utype=='customer')
        {
            $type=1;
            $status="unblocked";
            $data2=array('email'=>$email,'password'=>$password,'type'=>$type,'status'=>$status,'remember_token'=>'');
            DB::table('logins')->insert($data2);
        }
       else if($utype=='employee')
        {
            $type=2;
            $status="unblocked";
            $data2=array('email'=>$email,'password'=>$password,'type'=>$type,'status'=>$status,'remember_token'=>'');
            DB::table('logins')->insert($data2);
        }
        else
        {
            $type=3;
            $status="unblocked";
           $data2=array('email'=>$email,'password'=>$password,'type'=>$type,'status'=>$status,'remember_token'=>'');
            DB::table('logins')->insert($data2);
        }
        // @if (session('alert'))
        //<div class="alert alert-success">
            //{{ session('alert') }}
        //</div>
        //@endif
    // }
        //echo "<script>";
	  //echo 'alert("Registration successful")';
     //echo" </script>";
    //  @if (session('alert'))
    // <div class="alert alert-success">
    //     {{ session('alert') }}
    // </div>
    // @endif
    //return redirect('/index');
    echo "<script>";
	  echo 'alert("successfully registerd")';
	 echo" </script>";
	 return view('/index');

    }
}

    /**
     * Display the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function show(Register $register)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function edit(Register $register)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
   
	 public function update(Request $request,$email)
    {
        
     $fname = $request->input('fname');
	 $lname=$request->input('lname');
    $district = $request->input('district');
    $place = $request->input('place');
    $pin = $request->input('pin');
	$photo=$request->input('photo');
 $filename= $request->photo->getClientOriginalName();
  $request->photo->storeAs('public/upload',$filename);
$regid=db::table('registers')->where('email',"=",$email)->get();
		
			
$data=array("place"=>$place,"district"=>$district,"pin"=>$pin,"photo"=>$filename);
DB::table('registers')->where('email',"=",$email)->update($data);
		
		return redirect("customer.profile");

		
    }
     public function update1(Request $request,$email)
    {
        
    // $fname = $request->input('fname');
	 //$lname=$request->input('lname');
    $district = $request->input('district');
    $place = $request->input('place');
    $pin = $request->input('pin');
	$photo=$request->input('photo');
 $filename= $request->photo->getClientOriginalName();
  $request->photo->storeAs('public/upload',$filename);
$regid=db::table('registers')->where('email',"=",$email)->get();
		
			
$data=array("place"=>$place,"district"=>$district,"pin"=>$pin,"photo"=>$filename);
DB::table('registers')->where('email',"=",$email)->update($data);
		
		return redirect("employee.profile");

		
    }
    public function update2(Request $request,$email)
    {
        
     //$fname = $request->input('fname');
	 //$lname=$request->input('lname');
    $district = $request->input('district');
    $place = $request->input('place');
    $pin = $request->input('pin');
	$photo=$request->input('photo');
 $filename= $request->photo->getClientOriginalName();
  $request->photo->storeAs('public/upload',$filename);
$regid=db::table('registers')->where('email',"=",$email)->get();
		
			
$data=array("place"=>$place,"district"=>$district,"pin"=>$pin,"photo"=>$filename);
DB::table('registers')->where('email',"=",$email)->update($data);
		
		return redirect("carowner.profile");

		
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function destroy(Register $register)
    {
        //
    }
	public function block($email)
    {
     Register::where('email', $email)->update(array('status' => 'block'));
     
     return redirect("admin.clist");
 
}
 public function search(Request $req)
  {
     $search=$req->input('search');
     $customer=DB::select("select * from registers where email='$search'");
 return view('admin.search',compact('customer'));
 //return redirect('/searchemployees');
   }
   public function store2(Request $request)
   {
       $fdate = $request->input('fdate');
       $tdate = $request->input('tdate');
        $car_regno = $request->input('car_regno');
        $car_rent = $request->input('car_rent');
       //echo $car_regno;
       //$id = 0;
       if(session()->has('email'))
       {
        $x=session()->get('email');
       } 
            
   
       //$regid=DB::table('logins')->where('email',"=",$x)->get();
   // $loginid = '';
       //foreach($regid as $rid)
       //{
           //$id=$rid->id;
      // } 
         
      $data=array('email'=>$x,'car_regno'=>$car_regno,'car_rent'=>$car_rent,'date_from'=>$fdate,'date_to'=>$tdate,'status'=>1,'p_status'=>0,'c_status'=>0,'con_status'=>0);
       DB::table('booking')->insert($data);
       if(session()->has('b_id'))
       {
        $x1=session()->get('b_id');
       }
       echo "<script>";
    echo 'alert("successfully book details")';
   echo" </script>"; 
    return view('customer.book1',compact('x1'));

       //$rentsId = DB::select('select max(b_id) as b_id from rents') ;
       //DB::select('update reg_houses set Is_booked = 1 where h_id = '.$h_id) ;
       //$b_id = 0;
       //foreach($rentsId as $dataId)
       //{
           //$b_id = $dataId->b_id;
       //}   
       //return redirect("/book?id=" .$b_id);
   }
   
   
}