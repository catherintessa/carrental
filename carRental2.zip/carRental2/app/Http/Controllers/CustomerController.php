<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index()
    {
        return view('customer.index');
    }
    public function view()
    {
        return view('customer.view');
    }
    public function profile()
    {
        return view('customer.profile');
    }
    public function edit()
    {
        return view('customer.edit');
    }
    public function carlist1()
    {
        return view('customer.carlist1');
    }
    public function search()
    {
        return view('customer.search');
    }
    public function remove()
    {
        return view('customer.remove');
    }
    public function book()
    {
        return view('customer.book');
    }
    public function payment()
    {
        return view('customer.payment');
    }
    public function payment1()
    {
        return view('customer.payment1');
    }
    public function bookingh()
    {
        return view('customer.bookingh');
    }
    public function bookingc()
    {
        return view('customer.bookingc');
    }
}
