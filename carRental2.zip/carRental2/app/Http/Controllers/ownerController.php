<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ownerController extends Controller
{
   public function index()
   {
       return view('carowner.index');
   }
   public function adcar()
   {
       return view('carowner.adcar');
   }
}
