
<?php
namespace App\Http\Controllers;


use Illuminate\Http\Request;
use DB;
use Mail;
use App\Mail\MessageEmail;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class MailController extends Controller {

   public function html_email(Request $request) {
        $id  = $request->query('id'); ;
        $hItems = DB::select('SELECT  r.*  FROM booking as r inner join 
        payments as h on r.b_id = h.b_id inner join registers as l on l.email = r.email
        inner join logins 
        where r.b_id = '.$id);

        if(session()->has('email'))
        {
            $x=session()->get('email');
        }
       // $regid=DB::table('logins')->where('email',"=",$x)->get();
       $regid=DB::select("select * from registers,logins where logins.email='$x' and registers.email=logins.email");
        // $loginid = '';
        $status = '';
        $ownerName = '';
        $receiverName = '';
        $receivereasonrName = '';
        $toMailId = '';
        foreach($regid as $rid)
        {
            $ownerName = $rid->fname .' ' . $rid->lname;
        }

        foreach($hItems as $item)
        {
            //$status = $item ->hstatus;
            $toMailId = $item ->email;
           // $reason = $item ->reason;
            $receiverName = $item->fname .' ' . $item->lname;
        }
   
        $objDemo = new \stdClass();
       // $objDemo->status = $status;
        $objDemo->booking_id = $id;
        $objDemo->sender = $ownerName;
        $objDemo->receiver = $receiverName;
       // $objDemo->reason = $reason;
        
        $objDemo->paymentMessage = $paymentMessage;
        
         $toMailId = 'catherintessa@gmail.com';
        Mail::to($toMailId)->send(new MessageEmail($objDemo));
        // Mail::to($toMailId)->send($dataS, function($message) {
        //     $message->subject
        //         ('House Booking Confirmation of Booking Id :'.$id);
        //     $message->from('xyz@gmail.com','House Booking Confirmation');
        // });

        // echo "HTML Email Sent. Check your inbox.";
        $url= "admin.payment";
        echo "<script>";
      echo 'window.location.href="'.$url.'";';
	 echo" </script>";
   }
   
}

namespace App\Mail;
 
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
 
class MessageEmail extends Mailable
{
    use Queueable, SerializesModels;
     
    /**
     * The demo object instance.
     *
     * @var Demo
     */
    public $msg;
 
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($msg)
    {
        $this->msg = $msg;
    }
 
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from('rentzentric@leramiz.com')
                    ->view('mail')
                    ->subject('RentZentric('.$this->msg->b_id .') ');
    }
    
}

