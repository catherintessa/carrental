<?php

namespace App\Http\Controllers;

use App\Login;
use Illuminate\Http\Request;
use DB;
use Hash;
class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function show(Login $login)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function edit(Login $login)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Login $login)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function destroy(Login $login)
    {
        //
    }
	 public function Userlogin(Request $req)
        {
            $this->validate($req,[     
                'email' => 'required',
                'password' => 'required',                
             ]);
    
    
            $username=$req->input('email');
            $password=$req->input('password');
            
    
         
            $checkLogin=DB::table('logins')->where(['email'=>$username,'password'=>$password,])->get();
                $user=DB::table('registers')->where(['email'=>$username])->get();
            foreach ($checkLogin as $object)
            {
                if($object->password == $password)
                {
                    if($object->type == 0)
                    {
                        $req->session()->put('email',$username);
                        return view('admin.index');
                     }
                     elseif($object->type == 1)
                     {
                        $req->session()->put('email',$username);
                        return view('customer.index',compact('user'));
                     }
                     elseif($object->type ==2)
                     {
                        $req->session()->put('email',$username);
                    return view('employee.index');
                    }
                    elseif($object->type ==3)
                     {
                        $req->session()->put('email',$username);
                    return view('carowner.index');
                    }
                   else{
                    echo "<script>";
                    echo 'alert("wrong username or password")';
                   echo" </script>";
                   return view('/index');
                   }
               }
                else{
                    //return redirect('/index'); 
                    echo "<script>";
                    echo 'alert("wrong username or password")';
                 echo" </script>";
                    return view('/index'); 
                } 
    
}        
   //return redirect('/index'); 
   echo "<script>";
   echo 'alert("wrong username or password")';
echo" </script>";
   return view('/index');   
}
public function logout() {
    session()->flush();
    session_unset();
    //Auth::logout();
    return redirect('/index');
  }
  public function changepassword(Request $request)
    {
		$email = $request->input('email');
echo $confirmpassword = $request->input('confirmpassword');
echo $newpassword=$request->input('newpassword');
$oldpassword=$request->input('oldpassword');
 /*if($newpassword!=$confirmpassword)
 {
	 echo "<script>";
	  echo 'alert("Password doesnot match")';
	 echo" </script>";
	 return view('decocarts.index');
 }	*/
 $check=DB::table('logins')->where(['email'=>$email])->get();
if(count($check)>0)
 {
			foreach ($check as $object)
			{
				if($object->password = $oldpassword&&$object->email = $email &&$newpassword=$confirmpassword )
				{
					$login=array("password"=>$confirmpassword);
					DB::table('logins')->where('email',"=",$email)->update($login);
				}
				
			}
						echo "<script>";
	  echo 'alert("Successfully change your password")';
	 echo" </script>";
	 return view('admin.index');
}
 
 else
				{
					echo "<script>";
	  echo 'alert("Successfully change your password")';
	 echo" </script>";
	 return view('admin.index');
				}
	}
}
