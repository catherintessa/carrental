<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        return view('admin.index');
    }
    public function addcar()
    {
        return view('admin.addcar');
    }
    public function clist()
    {
        return view('admin.clist');
    }
    public function carowner()
    {
        return view('admin.carowner');
    }
    public function carlist()
    {
        return view('admin.carlist');
    }
    public function edit()
    {
        return view('admin.edit');
    }
    public function profile()
    {
        return view('admin.profile');
    }
    public function empw()
    {
        return view('admin.empw');
    }
    public function workingh()
    {
        return view('admin.workingh');
    }
    public function change()
    {
        return view('admin.change');
    }
    public function leave()
    {
        return view('admin.leave');
    }
    
}
