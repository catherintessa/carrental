<?php

namespace App\Http\Controllers;
use App\payment;
use Illuminate\Http\Request;
use DB;
use Carbon\Carbon;

class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
   

    /**
     * Display the specified resource.
     *
     * @param  \App\payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function show(payment $payment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function edit(payment $payment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, payment $payment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function destroy(payment $payment)
    {
        //
    }
	public function store(Request $request)
    {
       
       $b_id = $request->input('b_id');
       $amount = $request->input('amount');
       $email = $request->input('email');
       $name = $request->input('name');
       $cardno= $request->input('cardno');
       $cvv= $request->input('cvv');
	   $expdate= $request->input('expdate');
       $status= $request->input('status');
       $cdate= $request->input('cdate');
      
      
       //$u_type=$request->get('u_type');
       
       //$s=0;
     $data=array('b_id'=>$b_id,'amount'=>$amount,'email'=>$email,'name'=>$name,'cardno'=>$cardno,'cvv'=>$cvv,'expdate'=>$expdate,'status'=>1,'cdate'=>$cdate);
     
   DB::table('payments')->insert($data);
  
   $value = DB::table('booking')->where(['b_id'=>$b_id])->get();
   foreach ($value as $object)
   {
      if($object->status== '1')
      {
        $value1 = DB::table('booking')->where('b_id',$b_id)
         ->update(['status' => 0]);
      }
     }
   //return redirect('employee.index');
   echo "<script>";
	 echo 'alert("successfuly done payment")';
	echo" </script>";
	 return view('customer.payment1',compact('b_id'));
    }
    public function payment($id)
    {
       // $car=Adcar::all();
        //$qry="SELECT * from  payments where b_id='$id'" ;
        $qry="SELECT * from  booking  a INNER JOIN payments b ON a.b_id=b.b_id where b.b_id='$id' ";
        //$qry1="SELECT date_from from  booking  a INNER JOIN payments b ON a.b_id=b.b_id where b.b_id='$id' ";
        //echo $qry1;
        $car= DB::select($qry);
        return view ('admin.payment',compact('car'));
    }
    public function payment1(Request $request,$id)
    {
        $fdate = $request->input('fdate');
        $tdate = $request->input('tdate');
        $rent = $request->input('rent');
        $b_id= $request->input('b_id');
 // echo $fdate;
 // echo $tdate; 
  //echo $rent;
$start_date = strtotime("$fdate");
$start_date1 = strtotime("$tdate");
 $days=($start_date1 - $start_date)/60/60/24; 
 //echo $days;
 $rent1=$days*$rent;
// echo $rent1;
 $orig=$rent1-1000;
$original=$orig+1000;
 //echo $original;
//$days = $start->difference($end,'years');
//print $age;
    /*$days=date_diff($end,$start);*/
    //echo $days;
    $qry="SELECT * from  booking  a INNER JOIN payments b ON a.b_id=b.b_id where b.b_id='$id' ";
       // $car=Adcar::all();
        //$qry="SELECT * from  payments where b_id='$id'" ;
        //$qry="SELECT * from  booking  a INNER JOIN payments b ON a.b_id=b.b_id where b.b_id='$id' ";
        //$qry1="SELECT date_from from  booking  a INNER JOIN payments b ON a.b_id=b.b_id where b.b_id='$id' ";
        //echo $qry1;
        $car= DB::select($qry);
        return view ('admin.payment2',compact('car','original','b_id'));
    }
    public function cancellation(Request $request)
    {
        $b_id = $request->input('b_id');
        $email = $request->input('email');
       
//$days = $start->difference($end,'years');
//print $age;
    /*$days=date_diff($end,$start);*/
    //echo $days;
    $qry="SELECT * from  booking b inner join adcars a on a.car_regno=b.car_regno where b_id='$b_id' and email='$email' and b.c_status=0";
       // $car=Adcar::all();
        //$qry="SELECT * from  payments where b_id='$id'" ;
        //$qry="SELECT * from  booking  a INNER JOIN payments b ON a.b_id=b.b_id where b.b_id='$id' ";
        //$qry1="SELECT date_from from  booking  a INNER JOIN payments b ON a.b_id=b.b_id where b.b_id='$id' ";
        //echo $qry1;
        $car= DB::select($qry);
        return view ('customer.bookingc1',compact('car'));
    }
    public function cancellation1(Request $request)
    {
        $email= $request->input('email');
        $from = $request->input('from');
        $to = $request->input('to');
        $b_id = $request->input('b_id');
        $fd=date("20y-m-d");
        $date=date_create("$from");
        $f1=date_sub($date,date_interval_create_from_date_string("2 days"));
        $f2=date_format($f1,"Y-m-d");
        //echo $f2;
        if($fd<=$to)
        {
            if($fd<=$f2)
            {
            $status=1;
            $value = DB::table('booking')->where(['b_id'=>$b_id])->get();
            foreach ($value as $object)
            {
               if($object->c_status== '0')
               {
                 $value1 = DB::table('booking')->where('b_id',$b_id)
                  ->update(['c_status' => 1]);
               }
              }
            //return redirect('employee.index');
          
            echo "<script>";
              echo 'alert("successfuly cancel booking")';
             echo" </script>";
              return view('customer.index');
            }
            else
            {
            echo "<script>";
            echo 'alert("cancellation is not possible,you must done cancellation before two days of pickup date")';
           echo" </script>";
            return view('customer.index',compact('status')); 
        }
    }
        else{
            $status=0;
            echo "<script>";
            echo 'alert("Date is expired,cancellation is not possible")';
           echo" </script>";
            return view('customer.index',compact('status'));
          
        }
       // $email = $request->input('email');
       
//$days = $start->difference($end,'years');
//print $age;
    /*$days=date_diff($end,$start);*/
    //echo $days;
    $qry="SELECT * from  booking b inner join adcars a on a.car_regno=b.car_regno where b_id='$b_id' and email='$email' ";
       // $car=Adcar::all();
        //$qry="SELECT * from  payments where b_id='$id'" ;
        //$qry="SELECT * from  booking  a INNER JOIN payments b ON a.b_id=b.b_id where b.b_id='$id' ";
        //$qry1="SELECT date_from from  booking  a INNER JOIN payments b ON a.b_id=b.b_id where b.b_id='$id' ";
        //echo $qry1;
        $car= DB::select($qry);
        return view ('customer.bookingc1',compact('car'));
    }
}
