<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Me extends Model
{
    public $fillable=['name','email','mobile'];
}
