

$().ready(function(){
    //alert("test");
    $("#adcar").validate({
        rules:{
            car_model:{
                required:true,
                lettersonly: true,
                minlength:2

            },
            car_brand:{
                required:true,
                lettersonly: true,
                minlength:2

            },
			 rent:{
                required:true,
                

            }
    
        },
        messages:{
            car_model:{
                required: "Please enter car model must contain two letters",
                //lettersonly: "Only alphabets allowed",
                minlength: "Your name must contain atleast 2 charachter"
            }, 
            car_brand:{
                required: "Please enter car Brand must contain two letters",
                lettersonly: "Only alphabets allowed,must contain two letters",
                minlength: "Your name must contain atleast 2 charachter"
            }, 
            password:{
                required:"Plese provide Your Password",
                minlength:"Your Password must be Atleast 8 charachters long",
                pwcheck:"Atleast 1 character and 1 digit"
            },
            email:{
                required: "Please enter your Email",
                email: "Please enter valid Email",
                remote: "Email already exist"
                
            },
			 rent:{
                required: "Enter Valid rent",
                //lettersonly: "Only alphabets allowed,must contain two letters",
               // minlength: "Your name must contain atleast 2 charachter"
            }, 
			
        }

    });


    // $('#myPassword').passtrength({
    //     minChars: 4,
    //     passwordToggle: true,
    //     tooltip: true,
    //     eyeImg : "img/eye.svg"
    //   });
});