

$().ready(function(){
    //alert("test");
    $("#reg").validate({
        rules:{
            fname:{
                required:true,
                lettersonly: true,
                minlength:2

            },
            lname:{
                required:true,
                lettersonly: true,
                minlength:2

            },
            place:{
                required:true,
                lettersonly: true,
                minlength:2

            },
            password:{
                required:true,
                minlength:6,
                pwcheck: true
            },
            cno:{
                required:true,
                phoneno:true
            },
            pin:{
                required:true,
                pin:true
            },

            email:{
                required:true,
                email:true,
                //remote:"/check"
            }
        },
        messages:{
            fname:{
                required: "Please enter your name",
                lettersonly: "Only alphabets allowed",
                minlength: "Your name must contain atleast 2 charachter"
            }, 
            lname:{
                required: "Please enter your name",
                lettersonly: "Only alphabets allowed",
                minlength: "Your name must contain atleast 2 charachter"
            }, 
            password:{
                required:"Plese provide Your Password",
                minlength:"Your Password must be Atleast 7 charachters long",
                pwcheck:"Atleast 1 character and 1 digit"
            },
            email:{
                required: "Please enter your Email",
                email: "Please enter valid Email",
                remote: "Email already exist"
                
            }
        }

    });


    // $('#myPassword').passtrength({
    //     minChars: 4,
    //     passwordToggle: true,
    //     tooltip: true,
    //     eyeImg : "img/eye.svg"
    //   });
});