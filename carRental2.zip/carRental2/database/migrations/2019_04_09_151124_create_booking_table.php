<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBookingTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
     //public function up()
    //{
       // Schema::create('booking', function (Blueprint $table) {
            //$table->increments('b_id');
			//$table->integer('email')->unsigned();
			// $table->foreign('email')->references('email')->on('logins');
		
			//$table->integer('car_regno')->unsigned();
			//$table->foreign('car_regno')->references('car_regno')->on('adcars');
			
			//$table->string('date_from');
			//$table->string('date_to');
			//$table->string('bdate');
			//$table->string('status');
            //$table->timestamps();
        //});
//}

public function up()
    {
        Schema::create('booking', function (Blueprint $table) {
            $table->increments('b_id');
			$table->integer('car_regno');
			$table->integer('car_rent');
			$table->string('email');
			$table->string('date_from');
			$table->string('date_to');
			$table->string('status');
			$table->string('p_status');
			$table->string('c_status');
            $table->timestamps();
        });
}
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('booking');
    }
}
