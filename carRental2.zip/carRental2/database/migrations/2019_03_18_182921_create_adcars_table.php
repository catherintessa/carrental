<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAdcarsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('adcars', function (Blueprint $table) {
            $table->increments('id');
			$table->string('car_regno');
			$table->string('car_brand');
			$table->string('car_model');
			$table->string('car_ftype');
			$table->string('car_nofs');
			$table->string('car_actype');
			$table->string('car_rent');
			$table->string('car_image');
			$table->string('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('adcars');
    }
}
