<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>RentZentric Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="admin/css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="admin/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="admin/js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="admin/css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--static chart-->
<script src="js/Chart.min.js"></script>
<!--//charts-->
<!-- geo chart -->
    <script src="//cdn.jsdelivr.net/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
    <script>window.modernizr || document.write('<script src="lib/modernizr/modernizr-custom.js"><\/script>')</script>
    <!--<script src="lib/html5shiv/html5shiv.js"></script>-->
     <!-- Chartinator  -->
    <script src="js/chartinator.js" ></script>
    <script type="text/javascript">
        jQuery(function ($) {

            var chart3 = $('#geoChart').chartinator({
                tableSel: '.geoChart',

                columns: [{role: 'tooltip', type: 'string'}],
         
                colIndexes: [2],
             
                rows: [
                    ['China - 2015'],
                    ['Colombia - 2015'],
                    ['France - 2015'],
                    ['Italy - 2015'],
                    ['Japan - 2015'],
                    ['Kazakhstan - 2015'],
                    ['Mexico - 2015'],
                    ['Poland - 2015'],
                    ['Russia - 2015'],
                    ['Spain - 2015'],
                    ['Tanzania - 2015'],
                    ['Turkey - 2015']],
              
                ignoreCol: [2],
              
                chartType: 'GeoChart',
              
                chartAspectRatio: 1.5,
             
                chartZoom: 1.75,
             
                chartOffset: [-12,0],
             
                chartOptions: {
                  
                    width: null,
                 
                    backgroundColor: '#fff',
                 
                    datalessRegionColor: '#F5F5F5',
               
                    region: 'world',
                  
                    resolution: 'countries',
                 
                    legend: 'none',

                    colorAxis: {
                       
                        colors: ['#679CCA', '#337AB7']
                    },
                    tooltip: {
                     
                        trigger: 'focus',

                        isHtml: true
                    }
                }

               
            });                       
        });
    </script>
   <!--style>
	body {
 background-image: url("admin/images/download.jpg");
 background-color: #cccccc;
}
	</style-->
<!--geo chart-->

<!--skycons-icons-->
<script src="js/skycons.js"></script>
<!--//skycons-icons-->
</head>
<body background img src="storage/upload/download.jpg">	
<div class="page-container">	
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									 <a href="admin.index"> <h1>RentZentric</h1> 
									<!--<img id="logo" src="" alt="Logo"/>--> 
								  </a> 								
							</div>
                            <br>
                            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                            @if(session()->has('login_email'))
<h4>{{session()->get('login_email')}}</h4>
@endif
							<!--search-box-->
								<!--div class="search-box">
									
								</div><!--//end-search-box-->
							<div class="clearfix"> </div>
						 </div>
						 <div class="header-right">
							<div class="profile_details_left"><!--notifications of menu start -->
								<ul class="nofitications-dropdown">
									<li class="dropdown head-dpdn">
										<!--a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-envelope"></i><span class="badge">3</span></a>
										<ul class="dropdown-menu">
											<li>
												<!--div class="notification_header">
													<h3>You have 3 new messages</h3>
												</div-->
											</li>
											<!--li><a href="#">
											   <!--div class="user_img"><img src="images/p4.png" alt=""></div>
											   <div class="notification_desc">
												<p>Lorem ipsum dolor</p>
												<p><span>1 hour ago</span></p>
												</div-->
											   <div class="clearfix"></div>	
											</a></li>
											<!--li class="odd"><a href="#">
												<!--div class="user_img"><img src="images/p2.png" alt=""></div>
											   <div class="notification_desc">
												<p>Lorem ipsum dolor </p>
												<p><span>1 hour ago</span></p>
												</div-->
											  <div class="clearfix"></div>	
											</a></li>
											<!--li><a href="#">
											   <!--div class="user_img"><img src="images/p3.png" alt=""></div>
											   <div class="notification_desc">
												<p>Lorem ipsum dolor</p>
												<p><span>1 hour ago</span></p>
												</div>
											   <div class="clearfix"></div>	
											</a></li>
											<li>
												<div class="notification_bottom">
													<a href="#">See all messages</a>
												</div> 
											</li>
										</ul>
									</li>
									<li class="dropdown head-dpdn">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-bell"></i><span class="badge blue">3</span></a>
										<ul class="dropdown-menu">
											<li>
												<div class="notification_header">
													<h3>You have 3 new notification</h3>
												</div>
											</li>
											<li><a href="#">
												<div class="user_img"><img src="images/p5.png" alt=""></div>
											   <div class="notification_desc">
												<p>Lorem ipsum dolor</p>
												<p><span>1 hour ago</span></p>
												</div>
											  <div class="clearfix"></div>	
											 </a></li>
											 <li class="odd"><a href="#">
												<div class="user_img"><img src="images/p6.png" alt=""></div>
											   <div class="notification_desc">
												<p>Lorem ipsum dolor</p>
												<p><span>1 hour ago</span></p>
												</div>
											   <div class="clearfix"></div>	
											 </a></li>
											 <li><a href="#">
												<div class="user_img"><img src="images/p7.png" alt=""></div>
											   <div class="notification_desc">
												<p>Lorem ipsum dolor</p>
												<p><span>1 hour ago</span></p>
												</div>
											   <div class="clearfix"></div>	
											 </a></li>
											 <li>
												<div class="notification_bottom">
													<a href="#">See all notifications</a>
												</div> 
											</li>
										</ul>
									</li>	
									<li class="dropdown head-dpdn">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-tasks"></i><span class="badge blue1">9</span></a>
										<ul class="dropdown-menu">
											<li>
												<div class="notification_header">
													<h3>You have 8 pending task</h3>
												</div>
											</li>
											<li><a href="#">
												<div class="task-info">
													<span class="task-desc">Database update</span><span class="percentage">40%</span>
													<div class="clearfix"></div>	
												</div>
												<div class="progress progress-striped active">
													<div class="bar yellow" style="width:40%;"></div>
												</div>
											</a></li>
											<li><a href="#">
												<div class="task-info">
													<span class="task-desc">Dashboard done</span><span class="percentage">90%</span>
												   <div class="clearfix"></div>	
												</div>
												<div class="progress progress-striped active">
													 <div class="bar green" style="width:90%;"></div>
												</div>
											</a></li>
											<li><a href="#">
												<div class="task-info">
													<span class="task-desc">Mobile App</span><span class="percentage">33%</span>
													<div class="clearfix"></div>	
												</div>
											   <div class="progress progress-striped active">
													 <div class="bar red" style="width: 33%;"></div>
												</div>
											</a></li>
											<li><a href="#">
												<div class="task-info">
													<span class="task-desc">Issues fixed</span><span class="percentage">80%</span>
												   <div class="clearfix"></div>	
												</div>
												<div class="progress progress-striped active">
													 <div class="bar  blue" style="width: 80%;"></div>
												</div>
											</a></li>
											<li>
												<div class="notification_bottom">
													<a href="#">See all pending tasks</a>
												</div--> 
											</li>
										</ul>
									</li>	
								</ul>
								<div class="clearfix"> </div>
							</div>
							<!--notification menu end -->
							<div class="profile_details">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">	
												<span class="prfil-img"><img src="admin/images/p1.png" alt=""> </span> 
												<div class="user-name">
													<p>Tessa Catherin</p>
													<span>Administrator</span>
												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<!--ul class="dropdown-menu drp-mnu"-->
											<ul class="dropdown-menu drp-mnu">
											
											<li> <a href="/index"><i class="fa fa-sign-out"></i> Logout</a> </li>
                                            <li><a href=""  data-toggle="modal" data-target="#changeModal"><i class="fa fa-sign-out"></i>Change Password</a></li>
										</ul>
											
                                            
										</ul>
									</li>
								</ul>
							</div>
							<div class="clearfix"> </div>				
						</div>
				     <div class="clearfix"> </div>	
				</div>
<!--heder end here-->
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">
<!--market updates updates-->
<center><h2><font color="#000000">WELCOME:</h2>
	 @if(session()->has('email'))
<h4>{{session()->get('email')}}</font></h4>
@endif
  </center>
  <br>
  <br>
        <br>
        <br>
        <br>
  <center>
   <div class="preloader">
        <div class="preloader-spinner">
            <div class="loader-content">
                <img src="admin/images/preloader.gif" >
            </div>
        </div>
    </div>
    </center>    
  <br>
  <center>
   
        </div>
    </div>
    </center>    
<!--main page chit chating end here-->
<!--main page chart start here-->

<!--main page chart layer2-->

	      <!--//Progress bars-->
	      </div>
	</div>
	

<!--climate start here-->

<!--climate end here-->
</div>
<!--inner block end here-->
<!--copy rights start here-->

<!--COPY rights end here-->
</div>
</div>

    		


        
<!--slider menu-->
     <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>--> 
			  </a> </div>		    <div class="menu">	  

		      <ul id="menu" >
		        <li id="menu-home" ><a href="admin.index"><i class="fa fa-tachometer"></i><span>Dashboard</span></a></li>
		        <!--li><a href="#"><i class="fa fa-cogs"></i><span>Components</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul>
		            <li><a href="grids.html">Grids</a></li>
		            <li><a href="portlet.html">Portlets</a></li>		            
		          </ul>
		        </li-->
		        
		          <ul id="menu-comunicacao-sub" >
		           <li id="menu-academico" ><a href="#"><i class="fa fa-eye"></i><span>Views</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul id="menu-academico-sub" >
		          	 <li id="menu-academico-boletim" ><a href="admin.clist">Employees  List</a></li>
		           	<li id="menu-academico-boletim" ><a href="admin.carlist">Car List</a></li>
                     
                     
		            
		          </ul>
		        </li>
                <li><a href="admin.addcar"><i class="fa fa-car"></i><span>Add Car</span></a></li>
                <li><a href="admin.leave"><i  class="fa fa-calendar"></i><span>Leave</span></a></li>
		          <li><a href="admin.bookingh"><i class="fa fa-book"></i><span>Booking History</span></a></li>
                    <li><a href="admin.newcar"><i class="fa fa-car"></i><span>New Cars</span></a></li>
                     <!--li><a href="admin.payment"><i class="fa fa-usd"></i><span>Payment</span></a></li-->
		        <!--li id="menu-academico" ><a href="#"><i class="fa fa-file-text"></i><span>Pages</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul id="menu-academico-sub" >
		          	 <li id="menu-academico-boletim" ><a href="admin.carlist">Car List</a></li>
		            <li id="menu-academico-avaliacoes" ><a href="signup.html">Employee List</a></li>	
                    <li id="menu-academico-avaliacoes" ><a href="signup.html">Leave Request</a></li>		           
		          </ul>
		        </li-->
		        
		      
		      
		        
		        
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>
<form class="login-form" action="admin.indexs" method="post">
				 @csrf
				
            <div class="modal fade" id="changeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
			        <h5 class="modal-title" id="exampleModalLabel">Change Password</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
			     <div class="modal-body">
	  	<div class="form-group row">
            <div class="col-md-4">
				<label> User name: </label>
			</div>
            <div class="col-sm-8">
                <div class="form-group">
                <input type="text" class="form-control" name="email" placeholder="email" style="border-radius:12px" autocomplete="off" pattern=" /^[A-Za-z0-9._]*\@[A-Za-z]*\.[A-Za-z]{2,5}$/" required autocomplete="off" onKeyUp="this.value=this.value.toLowerCase();">
                </div>
            </div>
          </div>

		  <div class="form-group row">
            <div class="col-md-4">
				<label>Old Password: </label>
			</div>
            <div class="col-sm-8">
               
                <div class="form-group">
                <input type="password" class="form-control" name="oldpassword" id="oldpassword" placeholder="Old Password"  autocomplete="off" required="required" style="border-radius:12px";></br>
                </div>
            </div>
						
          </div>
          <div class="form-group row">
            <div class="col-md-4">
				<label>New Password: </label>
			</div>
            <div class="col-sm-8">
               
                <div class="form-group">
                <input type="password" class="form-control" name="newpassword" id="passwordl" placeholder=" New password"  autocomplete="off" style="border-radius:12px";required="required" onkeyup='checkl();' style="font-size:20px; font-color:green;" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 6 or more characters" >	</br>
                </div>
            </div>
						
          </div>
          <div class="form-group row">
            <div class="col-md-4">
				<label>Confirm Password: </label>
			</div>
            <div class="col-sm-8">
               
                <div class="form-group">
                <input type="password" class="form-control" name="confirmpassword" id="confirmpasswordl" placeholder="Re-enter Password"  autocomplete="off" style="border-radius:12px"required="required"autocomplete="off"onkeyup='checkl();'>	
                </div>
            </div-->
						
          </div>
      </div>
      <div class="modal-footer">
			<!-- <a class="btn btn-link" href="@if (Route::has('password.request'))">
                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif -->
                                <center><button type="submit" class="btn btn-primary btn-lg btn-block login-btn">Change Password</button></center>
      </div>
      </div>
      </div>
      </div>
            </div>
        </div>
    </div>
			
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="admin/js/jquery.nicescroll.js"></script>
		<script src="admin/js/scripts.js"></script>
		<!--//scrolling js-->
<script src="admin/js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>                     