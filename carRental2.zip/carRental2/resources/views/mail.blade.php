Hello <i>{{ $msg->receiver }}</i>,
<p>Your booking (ref: {{ $msg->b_id}}) </p>
  
  <p>Booling Confirmed </p>
Thank You,
<br/>
<i>{{ $msg->sender }}</i>