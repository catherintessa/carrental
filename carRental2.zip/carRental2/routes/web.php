<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::get('/index','indexController@index');
Route::post('/index','RegisterController@store');
Route::post('/index1','LoginController@Userlogin');
Route::any('/logout','LoginController@logout');
Route::post('admin.indexs','LoginController@changepassword');
//Route::resource('ulogin','LoginController');
Route::any('admin.index','adminController@index');

Route::any('carowner.index','ownerController@index');
Route::any('carowner.adcar','ownerController@adcar');
Route::any('carowner.profile','RegisterController@profile1');
//Route::any('customer.profile','customerController@profile');
Route::any('customer.profile','RegisterController@viewprofile');
//Route::any('customer1.profile','customerController@profile');
Route::any('employee.index','emController@index');
//Route::any('employee.index','RegisterController@profile');
Route::any('employee.carlist','AdcarController@index2');
Route::any('employee.leave','emController@leave');
Route::any('employee.lock_screen','emController@lock_screen');
Route::any('employee.applyleave','emController@applyleave');
Route::any('employee.profile','RegisterController@profile');
Route::any('employee.workingh','EmpwController@work');
Route::any('employee.leaves','LeaveController@leaves');
Route::get('admin.clist','RegisterController@index');
Route::get('admin.vieww/{email}','RegisterController@vieww');
Route::get('admin.search','RegisterController@search');
Route::get('admin.search1','AdcarController@search1');
Route::get('admin.search3','AdcarController@search3');
Route::get('admin.search2','AdcarController@search2');
Route::get('admin.bookingh','AdcarController@book2');
//Route::any('admin.clist','adminController@clist');
Route::any('customer.index2','MessageController@store');
Route::any('customer.index','customerController@index');
//Route::any('customer.profile','customerController@profile');
Route::any('customer.bookingc','customerController@bookingc');
Route::any('customer.bookingc1','PaymentController@cancellation');
Route::any('customer.bookingc2','PaymentController@cancellation1');
Route::any('admin.addcar1','AdcarController@store');
Route::any('admin.payment/{b_id}','paymentController@payment');
Route::any('admin.payment2/{b_id}','paymentController@payment1');
Route::any('admin.newcar','AdcarController@index6');
Route::get('approve2/{car_regno}','AdcarController@approve1');
Route::get('approve3/{b_id}','AdcarController@approve3');
Route::any('carowner.adcar1','AdcarController@store3');
Route::any('employee.applyleave1','LeaveController@store');
Route::any('admin.change','AdminController@change');
Route::get('approve/{id}','AdcarController@approve');
Route::get('approve1/{id}','LeaveController@approve1');
Route::get('approve4/{b_id}','AdcarController@approve4');
Route::any('admin.addcar','adminController@addcar');
Route::any('block1/{email}','RegisterController@block');
Route::any('admin.carlist','adcarController@index');
Route::any('carowner.carlist','adcarController@viewcar');
Route::any('/admin.carowner/{car_regno}','adcarController@car');
Route::any('admin.leave','LeaveController@leave');
Route::any('carowner.status','AdcarController@status');
Route::any('carowner.bookingh','AdcarController@bookingh');
Route::any('carowner.view/{email}','AdcarController@cview');
Route::any('customer.carlist1','adcarController@index1');
Route::any('customer.search','CustomerController@search');

//Route::any('customer.search','CustomerController@search');
Route::any('customer.payment/{b_id}','AdcarController@book5');
Route::any('customer.bookingh','AdcarController@book1');
Route::any('customer.payment2/{b_id}','RegisterController@index4');
//Route::any('customer.payment','MailController@sendMail');
Route::any('customer.book/{car_regno}','AdcarController@book');
Route::any('customer.book1','RegisterController@store2');
Route::any('customer.payment1','PaymentController@store');
Route::any('customer.remove','AdcarController@create');
Route::any('customer.view/{car_regno}','AdcarController@book3');
Route::any('admin.view/{email}','AdcarController@book4');
Route::any('/customer.display/{car_regno}','AdcarController@remove1');
//Route::any('customer.remove','AdcarController@store1');
Route::get('delete/{id}','AdcarController@destroy');
//Route::get('edit/{id}','AdcarController@change');
Route::any('/admin.edit/{id}','AdcarController@change')->name('admin.edit');
Route::any('/admin.edit2/{id}','AdcarController@update')->name('admin.edit');
Route::any('/customer.edit/{email}','RegisterController@change')->name('customer.edit');
Route::any('/carowner.edit/{email}','RegisterController@change2')->name('carowner.edit');
Route::any('/employee.edit/{email}','RegisterController@change1')->name('employee.edit');
Route::any('/customer.edit2/{email}','RegisterController@update')->name('customer.edit');
Route::any('/employee.edit1/{email}','RegisterController@update1')->name('employee.edit');
Route::any('/carowner.edit3/{email}','RegisterController@update2')->name('carowner.edit');
Route::any('/index2','MeController@store');
Route::get('/admin.empw/{email}','RegisterController@index1')->name('admin.empw');
//Route::get('/admin.empw/{email}','adminController@empw');
Route::any('/admin.empw1/{email}','AdcarController@store1')->name('admin.empw');
//Route::any('admin.payment','MailController@html_email');

//Route::get('admin.edit/{id}','adminController@index');
//Route::post('index','LogoutController@log');
//Route::get('customer.view','customerController@view');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
